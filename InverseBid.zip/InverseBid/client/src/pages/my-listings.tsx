import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Pencil, Trash2, Eye, PlusCircle } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function MyListings() {
  const { user, isLoading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("active");
  const [listingToDelete, setListingToDelete] = useState<number | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  // Fetch user's listings
  const { data: listings, isLoading, error } = useQuery({
    queryKey: ["/api/users", user?.id, "listings"],
    queryFn: async () => {
      if (!user) return [];
      const response = await fetch(`/api/users/${user.id}/listings`);
      if (!response.ok) {
        throw new Error("Failed to fetch listings");
      }
      return response.json();
    },
    enabled: !!user,
  });

  // Delete listing mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/listings/${id}`);
      return id;
    },
    onSuccess: (id) => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", user?.id, "listings"] });
      toast({
        title: "Annonce supprimée",
        description: "L'annonce a été supprimée avec succès.",
      });
      setListingToDelete(null);
      setIsDeleteDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur",
        description: `La suppression a échoué: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const handleDeleteClick = (id: number) => {
    setListingToDelete(id);
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (listingToDelete !== null) {
      deleteMutation.mutate(listingToDelete);
    }
  };

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="container mx-auto px-4 py-12 flex items-center justify-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
        <Footer />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="container mx-auto px-4 py-12">
          <Card>
            <CardContent className="pt-6">
              <p className="text-red-500">Une erreur est survenue lors du chargement de vos annonces.</p>
              <Button className="mt-4" onClick={() => navigate("/")}>Retour à l'accueil</Button>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  // Filter listings based on active tab
  const activeListings = listings?.filter((listing: any) => listing.isActive) || [];
  const inactiveListings = listings?.filter((listing: any) => !listing.isActive) || [];

  // Format date
  const formatListingDate = (date: string | Date) => {
    return format(new Date(date), "d MMMM yyyy", { locale: fr });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="container mx-auto px-4 py-8 flex-grow">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold">Mes annonces</h1>
            <Button onClick={() => navigate("/create-listing")}>
              <PlusCircle className="mr-2 h-4 w-4" />
              Nouvelle annonce
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Gérer vos annonces</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="w-full mb-6">
                  <TabsTrigger value="active" className="flex-1">
                    Annonces actives ({activeListings.length})
                  </TabsTrigger>
                  <TabsTrigger value="inactive" className="flex-1">
                    Annonces terminées ({inactiveListings.length})
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="active">
                  {activeListings.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <p>Vous n'avez pas d'annonces actives.</p>
                      <Button className="mt-4" onClick={() => navigate("/create-listing")}>
                        Créer une annonce
                      </Button>
                    </div>
                  ) : (
                    <div className="rounded-md border">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Titre</TableHead>
                            <TableHead>Prix de départ</TableHead>
                            <TableHead>Date de création</TableHead>
                            <TableHead>Statut</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {activeListings.map((listing: any) => (
                            <TableRow key={listing.id}>
                              <TableCell className="font-medium">{listing.title}</TableCell>
                              <TableCell>{listing.startingPrice}€</TableCell>
                              <TableCell>{formatListingDate(listing.createdAt)}</TableCell>
                              <TableCell>
                                <Badge variant="outline" className="bg-green-50 text-green-600">
                                  Active
                                </Badge>
                              </TableCell>
                              <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                  <Button 
                                    variant="outline" 
                                    size="sm"
                                    onClick={() => navigate(`/listings/${listing.id}`)}
                                  >
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                  <Button 
                                    variant="outline" 
                                    size="sm"
                                    // Implement edit functionality when available
                                    onClick={() => toast({
                                      title: "Fonctionnalité à venir",
                                      description: "La modification d'annonces sera bientôt disponible.",
                                    })}
                                  >
                                    <Pencil className="h-4 w-4" />
                                  </Button>
                                  <Button 
                                    variant="outline" 
                                    size="sm"
                                    className="text-red-500"
                                    onClick={() => handleDeleteClick(listing.id)}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="inactive">
                  {inactiveListings.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <p>Vous n'avez pas d'annonces terminées.</p>
                    </div>
                  ) : (
                    <div className="rounded-md border">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Titre</TableHead>
                            <TableHead>Prix de départ</TableHead>
                            <TableHead>Date de création</TableHead>
                            <TableHead>Statut</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {inactiveListings.map((listing: any) => (
                            <TableRow key={listing.id}>
                              <TableCell className="font-medium">{listing.title}</TableCell>
                              <TableCell>{listing.startingPrice}€</TableCell>
                              <TableCell>{formatListingDate(listing.createdAt)}</TableCell>
                              <TableCell>
                                <Badge variant="outline" className="bg-gray-100 text-gray-600">
                                  Terminée
                                </Badge>
                              </TableCell>
                              <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                  <Button 
                                    variant="outline" 
                                    size="sm"
                                    onClick={() => navigate(`/listings/${listing.id}`)}
                                  >
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                  <Button 
                                    variant="outline" 
                                    size="sm"
                                    className="text-red-500"
                                    onClick={() => handleDeleteClick(listing.id)}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
            <CardFooter className="text-sm text-gray-500 flex justify-center">
              <p>Les annonces terminées sont celles dont une offre a été acceptée ou qui ont été désactivées.</p>
            </CardFooter>
          </Card>
        </div>
      </main>

      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmer la suppression</AlertDialogTitle>
            <AlertDialogDescription>
              Êtes-vous sûr de vouloir supprimer cette annonce ? Cette action est irréversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-red-500 hover:bg-red-600"
            >
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      <Footer />
    </div>
  );
}
