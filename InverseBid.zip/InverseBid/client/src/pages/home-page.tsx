import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Listing } from "@shared/schema";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import CategoryQuickAccess from "@/components/listings/category-quick-access";
import ListingFilters from "@/components/listings/listing-filters";
import ListingCard from "@/components/listings/listing-card";
import { Button } from "@/components/ui/button";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Pagination, 
  PaginationContent, 
  PaginationItem, 
  PaginationLink, 
  PaginationNext, 
  PaginationPrevious 
} from "@/components/ui/pagination";
import { Search, Laptop, ShoppingCart, HandshakeIcon } from "lucide-react";
import { Loader2 } from "lucide-react";

type ListingWithSeller = Listing & { 
  seller: { 
    id: number; 
    username: string; 
    fullName?: string; 
    userType: string; 
    avatarUrl?: string | null; 
  } | null 
};

export default function HomePage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [filters, setFilters] = useState({
    category: undefined as string | undefined,
    sellerTypes: undefined as string[] | undefined,
    minPrice: undefined as number | undefined,
    maxPrice: undefined as number | undefined,
    conditions: undefined as string[] | undefined,
  });
  const [sort, setSort] = useState("recent");
  const [page, setPage] = useState(1);
  const limit = 12;

  // Parse URL search params for category filter
  useEffect(() => {
    const url = new URL(window.location.href);
    const category = url.searchParams.get("category");
    if (category) {
      setFilters(prev => ({ ...prev, category }));
    }
  }, []);

  // Fetch listings with filters
  const { data, isLoading, error } = useQuery<ListingWithSeller[]>({
    queryKey: ["/api/listings", filters, page, limit],
    queryFn: async () => {
      const queryParams = new URLSearchParams();
      
      if (filters.category) queryParams.append("category", filters.category);
      if (filters.sellerTypes?.length) filters.sellerTypes.forEach(type => queryParams.append("sellerType", type));
      if (filters.minPrice !== undefined) queryParams.append("minPrice", filters.minPrice.toString());
      if (filters.maxPrice !== undefined) queryParams.append("maxPrice", filters.maxPrice.toString());
      if (filters.conditions?.length) filters.conditions.forEach(cond => queryParams.append("condition", cond));
      
      queryParams.append("limit", limit.toString());
      queryParams.append("offset", ((page - 1) * limit).toString());
      
      const response = await fetch(`/api/listings?${queryParams.toString()}`);
      if (!response.ok) {
        throw new Error("Failed to fetch listings");
      }
      return response.json();
    }
  });

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    // Implement search logic here (could update filters or add a separate search API endpoint)
  };

  const handleSortChange = (value: string) => {
    setSort(value);
    // Implement sorting logic here
  };

  const handleApplyFilters = (newFilters: any) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
    setPage(1); // Reset to first page when filters change
  };

  const filteredListings = data || [];

  return (
    <div className="flex flex-col min-h-screen">
      <Header onSearch={handleSearch} />
      
      <main className="container mx-auto px-4 py-6 flex-grow">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-primary to-primary/80 rounded-xl p-5 mb-6 text-white">
          <div className="md:flex md:justify-between md:items-center">
            <div className="md:w-3/5 mb-4 md:mb-0">
              <div className="flex items-center mb-4">
                <img 
                  src="/logo.svg" 
                  alt="DealBil Logo" 
                  className="h-16 w-16 mr-3" 
                />
                <h1 className="text-3xl md:text-4xl font-bold font-sans">DealBil</h1>
              </div>
              <h2 className="text-2xl md:text-3xl font-bold font-sans mb-3">Inversez les règles de l'enchère !</h2>
              <p className="text-lg mb-5">Proposez votre prix, les vendeurs décident. Simple, sécurisé et accessible à tous.</p>
              <div className="flex space-x-4">
                {user ? (
                  <Button 
                    variant="secondary" 
                    className="bg-white text-primary font-semibold hover:bg-gray-100"
                    onClick={() => setLocation("/create-listing")}
                  >
                    Vendre un article
                  </Button>
                ) : (
                  <Button 
                    variant="secondary" 
                    className="bg-white text-primary font-semibold hover:bg-gray-100"
                    onClick={() => setLocation("/auth")}
                  >
                    S'inscrire / Se connecter
                  </Button>
                )}
                <Button 
                  variant="secondary" 
                  className="bg-orange-500 text-white font-semibold hover:bg-orange-600"
                >
                  Explorer
                </Button>
              </div>
            </div>
            <div className="md:w-2/5 md:flex md:justify-end">
              <img 
                src="https://images.unsplash.com/photo-1600880292089-90a7e086ee0c?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80" 
                alt="Poignée de main - Marché conclu" 
                className="rounded-lg shadow-lg w-full max-w-xs h-auto mx-auto"
              />
            </div>
          </div>
        </div>
        
        {/* Category Quick Access */}
        <CategoryQuickAccess />
        
        {/* Main Content */}
        <div className="flex flex-col md:flex-row gap-6">
          <aside className="md:w-1/4 lg:w-1/5">
            {/* Filters */}
            <ListingFilters onApplyFilters={handleApplyFilters} />
            
            {/* Help Section */}
            <div className="bg-white rounded-lg shadow-sm p-4">
              <h2 className="font-sans font-semibold text-lg mb-3">Comment ça marche ?</h2>
              <ol className="space-y-3 text-sm">
                <li className="flex">
                  <div className="bg-primary/10 rounded-full h-6 w-6 flex items-center justify-center mr-2 flex-shrink-0">
                    <span className="text-primary font-medium">1</span>
                  </div>
                  <p>Trouvez un article qui vous intéresse</p>
                </li>
                <li className="flex">
                  <div className="bg-primary/10 rounded-full h-6 w-6 flex items-center justify-center mr-2 flex-shrink-0">
                    <span className="text-primary font-medium">2</span>
                  </div>
                  <p>Proposez votre prix d'achat</p>
                </li>
                <li className="flex">
                  <div className="bg-primary/10 rounded-full h-6 w-6 flex items-center justify-center mr-2 flex-shrink-0">
                    <span className="text-primary font-medium">3</span>
                  </div>
                  <p>Attendez la réponse du vendeur</p>
                </li>
                <li className="flex">
                  <div className="bg-primary/10 rounded-full h-6 w-6 flex items-center justify-center mr-2 flex-shrink-0">
                    <span className="text-primary font-medium">4</span>
                  </div>
                  <p>Finalisez l'achat si votre offre est acceptée</p>
                </li>
              </ol>
              <Link href="#" className="text-primary text-sm font-medium block mt-3 hover:underline">En savoir plus</Link>
            </div>
          </aside>
          
          <div className="md:w-3/4 lg:w-4/5">
            {/* Results */}
            <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="font-sans font-semibold text-lg">Annonces récentes</h2>
                <div className="flex items-center">
                  <span className="text-sm mr-2">Trier par:</span>
                  <Select defaultValue={sort} onValueChange={handleSortChange}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Trier par" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="recent">Date (récent)</SelectItem>
                      <SelectItem value="price_asc">Prix (croissant)</SelectItem>
                      <SelectItem value="price_desc">Prix (décroissant)</SelectItem>
                      <SelectItem value="popularity">Popularité</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              {isLoading ? (
                <div className="flex justify-center items-center py-12">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                </div>
              ) : error ? (
                <div className="py-12 text-center text-red-500">
                  Une erreur est survenue lors du chargement des annonces.
                </div>
              ) : filteredListings.length === 0 ? (
                <div className="py-12 text-center text-gray-500">
                  Aucune annonce ne correspond à vos critères.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredListings.map((listing) => (
                    <ListingCard
                      key={listing.id}
                      id={listing.id}
                      title={listing.title}
                      startingPrice={listing.startingPrice}
                      imageUrl={listing.imageUrl}
                      seller={listing.seller || { id: 0, username: "Unknown" }}
                      createdAt={new Date(listing.createdAt)}
                      status="accepting_offers"
                      isPopular={Math.random() > 0.8} // Replace with actual logic
                      isNew={
                        new Date(listing.createdAt).getTime() > 
                        new Date().getTime() - 24 * 60 * 60 * 1000
                      }
                    />
                  ))}
                </div>
              )}
              
              {/* Pagination */}
              {filteredListings.length > 0 && (
                <div className="mt-6 flex justify-center">
                  <Pagination>
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious 
                          href="#" 
                          onClick={(e) => {
                            e.preventDefault();
                            if (page > 1) setPage(page - 1);
                          }}
                          className={page <= 1 ? "pointer-events-none opacity-50" : ""}
                        />
                      </PaginationItem>
                      {[...Array(3)].map((_, i) => (
                        <PaginationItem key={i}>
                          <PaginationLink
                            href="#"
                            onClick={(e) => {
                              e.preventDefault();
                              setPage(i + 1);
                            }}
                            isActive={page === i + 1}
                          >
                            {i + 1}
                          </PaginationLink>
                        </PaginationItem>
                      ))}
                      <PaginationItem>
                        <PaginationNext 
                          href="#" 
                          onClick={(e) => {
                            e.preventDefault();
                            setPage(page + 1);
                          }}
                          // Disable when no more pages
                          className={filteredListings.length < limit ? "pointer-events-none opacity-50" : ""}
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                </div>
              )}
            </div>
            
            {/* How It Works */}
            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
              <h2 className="font-sans font-semibold text-xl mb-4 text-center">Comment fonctionne Enchère Inversée ?</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="mx-auto w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                    <Search className="text-primary text-2xl" />
                  </div>
                  <h3 className="font-medium mb-2">1. Trouvez des articles</h3>
                  <p className="text-sm text-gray-600">Parcourez des milliers d'annonces de particuliers et professionnels dans toutes les catégories.</p>
                </div>
                
                <div className="text-center">
                  <div className="mx-auto w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                    <ShoppingCart className="text-primary text-2xl" />
                  </div>
                  <h3 className="font-medium mb-2">2. Proposez votre prix</h3>
                  <p className="text-sm text-gray-600">Faites une offre privée au vendeur selon ce que vous êtes prêt à payer pour l'article.</p>
                </div>
                
                <div className="text-center">
                  <div className="mx-auto w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                    <HandshakeIcon className="text-primary text-2xl" />
                  </div>
                  <h3 className="font-medium mb-2">3. Finalisez l'achat</h3>
                  <p className="text-sm text-gray-600">Si le vendeur accepte votre offre, concluez l'achat en toute sécurité via notre plateforme.</p>
                </div>
              </div>
              
              <div className="mt-6 text-center">
                {!user ? (
                  <Button 
                    variant="secondary"
                    className="bg-orange-500 text-white font-medium hover:bg-orange-600"
                    onClick={() => setLocation("/auth")}
                  >
                    Créer un compte gratuitement
                  </Button>
                ) : (
                  <Button 
                    variant="secondary"
                    className="bg-orange-500 text-white font-medium hover:bg-orange-600"
                    onClick={() => setLocation("/create-listing")}
                  >
                    Créer une annonce
                  </Button>
                )}
              </div>
            </div>
            
            {/* Trust Signals */}
            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
              <h2 className="font-sans font-semibold text-xl mb-4 text-center">Pourquoi choisir DealBil ?</h2>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="border border-gray-100 rounded-lg p-4 flex flex-col items-center text-center">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-primary">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285z" />
                    </svg>
                  </div>
                  <h3 className="font-medium mb-1">Transactions sécurisées</h3>
                  <p className="text-sm text-gray-600">Paiements protégés et données personnelles chiffrées.</p>
                </div>
                
                <div className="border border-gray-100 rounded-lg p-4 flex flex-col items-center text-center">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-primary">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m.94 3.198l.001.031c0 .225-.012.447-.037.666A11.944 11.944 0 0112 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 016 18.719m12 0a5.971 5.971 0 00-.941-3.197m0 0A5.995 5.995 0 0012 12.75a5.995 5.995 0 00-5.058 2.772m0 0a3 3 0 00-4.681 2.72 8.986 8.986 0 003.74.477m.94-3.197a5.971 5.971 0 00-.94 3.197M15 6.75a3 3 0 11-6 0 3 3 0 016 0zm6 3a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0zm-13.5 0a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0z" />
                    </svg>
                  </div>
                  <h3 className="font-medium mb-1">Communauté active</h3>
                  <p className="text-sm text-gray-600">Des milliers d'utilisateurs et de nouvelles annonces chaque jour.</p>
                </div>
                
                <div className="border border-gray-100 rounded-lg p-4 flex flex-col items-center text-center">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-primary">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v12m-3-2.818l.879.659c1.171.879 3.07.879 4.242 0 1.172-.879 1.172-2.303 0-3.182C13.536 12.219 12.768 12 12 12c-.725 0-1.45-.22-2.003-.659-1.106-.879-1.106-2.303 0-3.182s2.9-.879 4.006 0l.415.33M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <h3 className="font-medium mb-1">Économies garanties</h3>
                  <p className="text-sm text-gray-600">Négociez directement avec les vendeurs pour le meilleur prix.</p>
                </div>
                
                <div className="border border-gray-100 rounded-lg p-4 flex flex-col items-center text-center">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-primary">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193-.34.027-.68.052-1.02.072v3.091l-3-3c-1.354 0-2.694-.055-4.02-.163a2.115 2.115 0 01-.825-.242m9.345-8.334a2.126 2.126 0 00-.476-.095 48.64 48.64 0 00-8.048 0c-1.131.094-1.976 1.057-1.976 2.192v4.286c0 .837.46 1.58 1.155 1.951m9.345-8.334V6.637c0-1.621-1.152-3.026-2.76-3.235A48.455 48.455 0 0011.25 3c-2.115 0-4.198.137-6.24.402-1.608.209-2.76 1.614-2.76 3.235v6.226c0 1.621 1.152 3.026 2.76 3.235.577.075 1.157.14 1.74.194V21l4.155-4.155" />
                    </svg>
                  </div>
                  <h3 className="font-medium mb-1">Support réactif</h3>
                  <p className="text-sm text-gray-600">Notre équipe est disponible 7j/7 pour vous aider.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      {/* App Install Banner */}
      <div className="bg-primary py-4 text-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center mb-4 md:mb-0">
              <Laptop className="h-6 w-6 mr-3" />
              <div>
                <h3 className="font-medium">Téléchargez notre application mobile</h3>
                <p className="text-sm text-white/80">Recevez des notifications en temps réel pour vos offres</p>
              </div>
            </div>
            <div className="flex space-x-3">
              <Button variant="outline" className="bg-black text-white border-black hover:bg-black/80">
                <svg className="h-5 w-5 mr-2" viewBox="0 0 384 512" fill="currentColor">
                  <path d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-15 0-49.4-19.7-76.4-19.7C63.3 141.2 4 184.8 4 273.5q0 39.3 14.4 81.2c12.8 36.7 59 126.7 107.2 125.2 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-82.5 102.6-119.3-65.2-30.7-61.7-90-61.7-91.9zm-56.6-164.2c27.3-32.4 24.8-61.9 24-72.5-24.1 1.4-52 16.4-67.9 34.9-17.5 19.8-27.8 44.3-25.6 71.9 26.1 2 49.9-11.4 69.5-34.3z"/>
                </svg>
                <div className="text-sm">
                  <span className="block text-xs">Télécharger sur</span>
                  <span className="font-medium">App Store</span>
                </div>
              </Button>
              <Button variant="outline" className="bg-black text-white border-black hover:bg-black/80">
                <svg className="h-5 w-5 mr-2" viewBox="0 0 512 512" fill="currentColor">
                  <path d="M325.3 234.3L104.6 13l280.8 161.2-60.1 60.1zM47 0C34 6.8 25.3 19.2 25.3 35.3v441.3c0 16.1 8.7 28.5 21.7 35.3l256.6-256L47 0zm425.2 225.6l-58.9-34.1-65.7 64.5 65.7 64.5 60.1-34.1c18-14.3 18-46.5-1.2-60.8zM104.6 499l280.8-161.2-60.1-60.1L104.6 499z"/>
                </svg>
                <div className="text-sm">
                  <span className="block text-xs">Télécharger sur</span>
                  <span className="font-medium">Google Play</span>
                </div>
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Advertising Section */}
      <div className="container mx-auto px-4 py-6 mb-8">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="font-sans font-semibold text-xl mb-4 text-center">Monétisez votre présence sur DealBil</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-slate-50 border border-gray-100 rounded-lg p-5">
              <div className="flex items-start mb-4">
                <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center mr-4 flex-shrink-0">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-blue-600">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3v11.25A2.25 2.25 0 006 16.5h2.25M3.75 3h-1.5m1.5 0h16.5m0 0h1.5m-1.5 0v11.25A2.25 2.25 0 0118 16.5h-2.25m-7.5 0h7.5m-7.5 0l-1 3m8.5-3l1 3m0 0l.5 1.5m-.5-1.5h-9.5m0 0l-.5 1.5m.75-9l3-3 2.148 2.148A12.061 12.061 0 0116.5 7.605" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-medium text-lg mb-2">Publicité sur DealBil</h3>
                  <p className="text-gray-600 mb-3">Augmentez votre visibilité et atteignez des milliers de clients potentiels avec nos emplacements publicitaires stratégiques.</p>
                  <Link href="/monetization" className="flex items-center text-primary font-medium hover:underline">
                    Découvrir nos solutions publicitaires
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 ml-1">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
                    </svg>
                  </Link>
                </div>
              </div>
            </div>
            
            <div className="bg-amber-50 border border-gray-100 rounded-lg p-5">
              <div className="flex items-start mb-4">
                <div className="w-12 h-12 rounded-lg bg-amber-100 flex items-center justify-center mr-4 flex-shrink-0">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-amber-600">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M10.34 15.84c-.688-.06-1.386-.09-2.09-.09H7.5a4.5 4.5 0 110-9h.75c.704 0 1.402-.03 2.09-.09m0 9.18c.253.962.584 1.892.985 2.783.247.55.06 1.21-.463 1.511l-.657.38c-.551.318-1.26.117-1.527-.461a20.845 20.845 0 01-1.44-4.282m3.102.069a18.03 18.03 0 01-.59-4.59c0-1.586.205-3.124.59-4.59m0 9.18a23.848 23.848 0 018.835 2.535M10.34 6.66a23.847 23.847 0 008.835-2.535m0 0A23.74 23.74 0 0018.795 3m.38 1.125a23.91 23.91 0 011.014 5.395m-1.014 8.855c-.118.38-.245.754-.38 1.125m.38-1.125a23.91 23.91 0 001.014-5.395m0-3.46c.495.413.811 1.035.811 1.73 0 .695-.316 1.317-.811 1.73m0-3.46a24.347 24.347 0 010 3.46" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-medium text-lg mb-2">Programme d'affiliation</h3>
                  <p className="text-gray-600 mb-3">Devenez partenaire et gagnez des commissions en recommandant notre plateforme à votre audience.</p>
                  <Link href="/monetization" className="flex items-center text-amber-600 font-medium hover:underline">
                    Rejoindre notre programme 
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 ml-1">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
                    </svg>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}
