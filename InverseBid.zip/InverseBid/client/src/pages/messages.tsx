import { useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import ConversationList from "@/components/messaging/conversation-list";
import MessageList from "@/components/messaging/message-list";
import MessageForm from "@/components/messaging/message-form";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useQuery } from "@tanstack/react-query";

type MessageParams = {
  userId?: string;
};

export default function Messages() {
  const { userId } = useParams<MessageParams>();
  const [, navigate] = useLocation();
  const { user, isLoading: authLoading } = useAuth();
  
  const selectedUserId = userId ? parseInt(userId) : undefined;
  
  // Fetch conversation user details if a specific conversation is selected
  const { data: conversationData, isLoading: conversationLoading } = useQuery({
    queryKey: [`/api/conversations/${selectedUserId}`],
    enabled: !!selectedUserId,
  });

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  if (authLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="container mx-auto px-4 py-12 flex justify-center items-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
        <Footer />
      </div>
    );
  }

  // Don't render anything if redirecting
  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="container mx-auto px-4 py-8 flex-grow">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold mb-6">Messages</h1>
          
          <Card className="h-[calc(100vh-300px)] min-h-[500px]">
            <CardContent className="p-0 h-full flex">
              {/* Conversation list (left sidebar) */}
              <div className="w-1/3 border-r h-full">
                <ConversationList selectedUserId={selectedUserId} />
              </div>
              
              {/* Message area (right side) */}
              <div className="w-2/3 flex flex-col h-full">
                {selectedUserId ? (
                  <>
                    {/* Conversation header */}
                    <div className="p-4 border-b">
                      <h2 className="font-medium">
                        {conversationData?.user?.fullName || conversationData?.user?.username || "Conversation"}
                      </h2>
                    </div>
                    
                    {/* Messages */}
                    <div className="flex-1 overflow-hidden">
                      <MessageList receiverId={selectedUserId} />
                    </div>
                    
                    {/* Message input */}
                    <MessageForm receiverId={selectedUserId} />
                  </>
                ) : (
                  <div className="flex items-center justify-center h-full text-gray-500">
                    <div className="text-center">
                      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 mx-auto mb-4 text-gray-400">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M8.625 12a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H8.25m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 01-2.555-.337A5.972 5.972 0 015.41 20.97a5.969 5.969 0 01-.474-.065 4.48 4.48 0 00.978-2.025c.09-.457-.133-.901-.467-1.226C3.93 16.178 3 14.189 3 12c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25z" />
                      </svg>
                      <p className="text-lg font-medium">Sélectionnez une conversation</p>
                      <p className="text-sm mt-2">Cliquez sur une conversation dans la liste pour afficher les messages.</p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
}
