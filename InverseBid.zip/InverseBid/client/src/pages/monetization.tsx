import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Info, Star } from "lucide-react";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";

export default function Monetization() {
  const { user } = useAuth();
  const [viewType, setViewType] = useState<"seller" | "advertiser">("seller");

  // Plans for sellers
  const subscriptionPlans = [
    {
      id: 1,
      name: "Basic",
      price: 0,
      billingCycle: "mensuel",
      features: [
        "5 annonces actives maximum",
        "Visibilité standard",
        "Support par email",
      ],
      isPopular: false,
      color: "bg-gray-100",
    },
    {
      id: 2,
      name: "Premium",
      price: 29.99,
      billingCycle: "mensuel",
      features: [
        "Annonces illimitées",
        "Mise en avant dans les résultats",
        "Badge vendeur vérifié",
        "Statistiques détaillées",
        "Support prioritaire",
      ],
      isPopular: true,
      color: "bg-orange-50",
    },
    {
      id: 3,
      name: "Professionnel",
      price: 99.99,
      billingCycle: "mensuel",
      features: [
        "Tout ce qui est inclus dans Premium",
        "Outils de gestion avancés",
        "API d'intégration",
        "Commission réduite (3% au lieu de 5%)",
        "Support dédié",
        "Rapports de performance mensuels",
      ],
      isPopular: false,
      color: "bg-blue-50",
    },
  ];

  // Promotion options for listings
  const promotionOptions = [
    {
      id: 1,
      name: "Mise en avant basique",
      description: "Votre annonce reste en haut des résultats pendant 24 heures",
      price: 9.99,
      duration: 1, // days
      features: [
        "Position premium dans les résultats de recherche",
        "Badge 'En vedette'",
      ],
      color: "bg-yellow-50"
    },
    {
      id: 2,
      name: "Visibilité étendue",
      description: "Présence renforcée avec bannière colorée pendant 3 jours",
      price: 19.99,
      duration: 3, // days
      features: [
        "Mise en avant dans les résultats",
        "Fond coloré distinctif",
        "Badge 'Offre spéciale'",
        "Inclusion dans la newsletter hebdomadaire",
      ],
      color: "bg-green-50"
    },
    {
      id: 3,
      name: "Pack premium",
      description: "Visibilité maximale pendant une semaine entière",
      price: 39.99,
      duration: 7, // days
      features: [
        "Première position garantie",
        "Annonce en vedette sur la page d'accueil",
        "Grande vignette avec plusieurs images",
        "Badge 'Premium'",
        "Promotion sur nos réseaux sociaux",
      ],
      color: "bg-purple-50"
    }
  ];

  // Advertising spaces
  const adSpaces = [
    {
      id: 1,
      name: "Bannière supérieure",
      location: "header",
      size: "Bannière (728×90)",
      price: 49.99,
      description: "Bannière visible en haut de chaque page, maximum de visibilité",
      color: "bg-blue-50"
    },
    {
      id: 2,
      name: "Encart latéral",
      location: "sidebar",
      size: "Rectangle (300×250)",
      price: 29.99,
      description: "Publicité dans la barre latérale des pages de résultats et des annonces",
      color: "bg-green-50"
    },
    {
      id: 3,
      name: "Annonce native",
      location: "listing_page",
      size: "Intégrée (format annonce)",
      price: 99.99,
      description: "Votre produit affiché comme une annonce normale mais marqué comme sponsorisé",
      color: "bg-orange-50"
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-10">
            <h1 className="text-4xl font-bold mb-4">Options de monétisation</h1>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Maximisez votre visibilité et augmentez vos ventes avec nos solutions adaptées à vos besoins.
            </p>
          </div>

          <Tabs defaultValue="subscriptions" className="mb-12">
            <div className="flex justify-center mb-6">
              <TabsList>
                <TabsTrigger value="subscriptions">Abonnements</TabsTrigger>
                <TabsTrigger value="promotions">Promotions d'annonces</TabsTrigger>
                <TabsTrigger value="advertising">Espaces publicitaires</TabsTrigger>
                <TabsTrigger value="adsense">Google AdSense</TabsTrigger>
              </TabsList>
            </div>

            {/* Subscription Plans */}
            <TabsContent value="subscriptions">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {subscriptionPlans.map((plan) => (
                  <Card key={plan.id} className={`${plan.color} relative overflow-hidden`}>
                    {plan.isPopular && (
                      <div className="absolute top-0 right-0">
                        <Badge className="bg-orange-500 text-white px-3 py-1 rounded-none rounded-bl-lg">
                          <Star className="h-3 w-3 mr-1" /> Populaire
                        </Badge>
                      </div>
                    )}
                    <CardHeader>
                      <CardTitle>{plan.name}</CardTitle>
                      <CardDescription>
                        <div className="flex items-baseline mt-2">
                          <span className="text-3xl font-bold">
                            {plan.price === 0 ? "Gratuit" : `${plan.price.toFixed(2)}€`}
                          </span>
                          {plan.price > 0 && (
                            <span className="text-sm text-gray-500 ml-1">/{plan.billingCycle}</span>
                          )}
                        </div>
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {plan.features.map((feature, index) => (
                          <li key={index} className="flex items-start">
                            <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Button className={plan.isPopular ? "bg-orange-500 hover:bg-orange-600 w-full" : "w-full"}>
                        {plan.price === 0 ? "Plan actuel" : "Souscrire"}
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Promotion Options */}
            <TabsContent value="promotions">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {promotionOptions.map((option) => (
                  <Card key={option.id} className={`${option.color}`}>
                    <CardHeader>
                      <CardTitle>{option.name}</CardTitle>
                      <CardDescription>{option.description}</CardDescription>
                      <div className="mt-2">
                        <span className="text-2xl font-bold">{option.price.toFixed(2)}€</span>
                        <span className="text-sm text-gray-500 ml-1">
                          pour {option.duration} jour{option.duration > 1 ? "s" : ""}
                        </span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {option.features.map((feature, index) => (
                          <li key={index} className="flex items-start">
                            <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Button className="w-full">Promouvoir mon annonce</Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Advertising Spaces */}
            <TabsContent value="advertising">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {adSpaces.map((space) => (
                  <Card key={space.id} className={`${space.color}`}>
                    <CardHeader>
                      <CardTitle>{space.name}</CardTitle>
                      <CardDescription>{space.description}</CardDescription>
                      <div className="mt-2">
                        <Badge variant="outline" className="mr-2">
                          {space.size}
                        </Badge>
                        <span className="text-2xl font-bold">{space.price.toFixed(2)}€</span>
                        <span className="text-sm text-gray-500 ml-1">/jour</span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="bg-gray-100 border border-dashed border-gray-300 rounded-md p-4 h-40 flex items-center justify-center">
                        <div className="text-center">
                          <Info className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                          <p className="text-gray-500 text-sm">Aperçu de l'emplacement publicitaire</p>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button className="w-full">Réserver cet espace</Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Google AdSense */}
            <TabsContent value="adsense">
              <div className="max-w-4xl mx-auto">
                <div className="bg-white rounded-lg shadow-sm p-8 mb-6">
                  <div className="flex items-center mb-6">
                    <div className="flex-shrink-0 mr-4">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" className="h-12 w-12">
                        <path fill="#FBBC04" d="M96 301.38v-90.76h90.76V392.14h90.76V210.62H96z"/>
                        <path fill="#34A853" d="M299.24 119.86h-90.76V210.62h181.52v181.52H480V119.86"/>
                        <path fill="#EA4335" d="M87.53 256c0-35.27 13.17-67.47 34.85-92h-94C10.16 194.84 0 224.46 0 256c0 31.54 10.16 61.16 28.38 91.99h94c-21.68-24.52-34.85-56.72-34.85-91.99z"/>
                        <path fill="#4285F4" d="M480 210.62v-90.76H299.24V32H96v32.37c35.27 0 67.47 13.17 92 34.85 28.85-25.37 65.69-39.21 111.24-39.21V178.24h180.76v119.63 94.27H424.5c-21.53 24.53-56.48 39.21-94.5 39.21-47.79 0-91.46-20.42-119.04-52.74C184.84 401.85 154.46 412 123.38 412H32.37C65.61 471.11 128.23 512 205.62 512c51.4 0 98.96-24.19 130.77-42.55 31.81 18.36 89.74 42.55 141.14 42.55v-90.76H389.99 297.9c28.85-25.37 37.91-55.91 37.91-101.62 0-37.46-12.25-78.43-37.91-109.01h90.1z"/>
                      </svg>
                    </div>
                    <div>
                      <h2 className="text-2xl font-bold">Programme Google AdSense</h2>
                      <p className="text-gray-600">Monétisez votre trafic en hébergeant des annonces Google sur la plateforme DealBil</p>
                    </div>
                  </div>

                  <div className="mb-8">
                    <h3 className="text-xl font-semibold mb-4">Comment ça fonctionne ?</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mb-3">
                          <span className="font-bold text-blue-600">1</span>
                        </div>
                        <h4 className="font-medium mb-2">Inscription</h4>
                        <p className="text-sm">Inscrivez-vous au programme Google AdSense avec votre compte DealBil pour devenir éditeur.</p>
                      </div>
                      
                      <div className="bg-green-50 p-4 rounded-lg">
                        <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mb-3">
                          <span className="font-bold text-green-600">2</span>
                        </div>
                        <h4 className="font-medium mb-2">Intégration</h4>
                        <p className="text-sm">Nous intégrons des annonces Google dans vos pages de listings et votre profil vendeur.</p>
                      </div>
                      
                      <div className="bg-amber-50 p-4 rounded-lg">
                        <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center mb-3">
                          <span className="font-bold text-amber-600">3</span>
                        </div>
                        <h4 className="font-medium mb-2">Revenus</h4>
                        <p className="text-sm">Vous recevez une part des revenus publicitaires générés par le trafic sur vos annonces.</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg mb-8">
                    <h3 className="text-xl font-semibold mb-4">Emplacements des annonces</h3>
                    <div className="space-y-4">
                      <div className="flex items-start">
                        <Check className="h-5 w-5 text-green-500 mr-3 mt-1" />
                        <div>
                          <h4 className="font-medium">Sur vos pages de listings</h4>
                          <p className="text-sm text-gray-600">Les annonces s'affichent sur les pages détaillées de vos produits à vendre.</p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <Check className="h-5 w-5 text-green-500 mr-3 mt-1" />
                        <div>
                          <h4 className="font-medium">Sur votre profil vendeur</h4>
                          <p className="text-sm text-gray-600">Les visiteurs de votre profil verront des annonces pertinentes.</p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <Check className="h-5 w-5 text-green-500 mr-3 mt-1" />
                        <div>
                          <h4 className="font-medium">Dans les résultats de recherche</h4>
                          <p className="text-sm text-gray-600">Des annonces ciblées apparaissent à côté de vos produits dans les résultats.</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="text-center">
                    <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                      Rejoindre le programme AdSense
                    </Button>
                    <p className="text-sm text-gray-500 mt-3">
                      Seuls les vendeurs avec un minimum de 10 annonces actives peuvent participer
                    </p>
                  </div>
                </div>

                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h3 className="text-xl font-semibold mb-4">Conditions de participation</h3>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <div className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center mr-3 flex-shrink-0">
                        <span className="text-gray-600 font-medium">•</span>
                      </div>
                      <p>Avoir un compte vendeur actif depuis au moins 3 mois</p>
                    </li>
                    <li className="flex items-start">
                      <div className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center mr-3 flex-shrink-0">
                        <span className="text-gray-600 font-medium">•</span>
                      </div>
                      <p>Maintenir un minimum de 10 annonces actives</p>
                    </li>
                    <li className="flex items-start">
                      <div className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center mr-3 flex-shrink-0">
                        <span className="text-gray-600 font-medium">•</span>
                      </div>
                      <p>Respecter les règles de contenu de Google AdSense</p>
                    </li>
                    <li className="flex items-start">
                      <div className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center mr-3 flex-shrink-0">
                        <span className="text-gray-600 font-medium">•</span>
                      </div>
                      <p>Générer un minimum de 100 visites mensuelles sur vos annonces</p>
                    </li>
                    <li className="flex items-start">
                      <div className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center mr-3 flex-shrink-0">
                        <span className="text-gray-600 font-medium">•</span>
                      </div>
                      <p>DealBil conserve 30% des revenus générés par les annonces AdSense</p>
                    </li>
                  </ul>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          {/* Commission Information */}
          <section className="bg-blue-50 rounded-lg p-8 text-center mb-12">
            <h2 className="text-2xl font-bold mb-4">Commission sur les transactions</h2>
            <p className="text-lg mb-6">
              DealBil prélève une commission de <strong>5%</strong> sur chaque transaction réussie.
              <br />
              Les vendeurs professionnels bénéficient d'un taux réduit de <strong>3%</strong>.
            </p>
            <div className="flex justify-center gap-8">
              <div className="bg-white rounded-lg shadow-sm p-4 w-48">
                <h3 className="font-semibold text-lg">Vendeurs standard</h3>
                <p className="text-3xl font-bold text-orange-500 mt-2">5%</p>
              </div>
              <div className="bg-white rounded-lg shadow-sm p-4 w-48">
                <h3 className="font-semibold text-lg">Vendeurs pro</h3>
                <p className="text-3xl font-bold text-blue-500 mt-2">3%</p>
              </div>
            </div>
          </section>

          {/* Call to Action */}
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4">Prêt à augmenter votre visibilité ?</h2>
            <p className="text-lg mb-6">
              Choisissez l'option qui convient le mieux à vos besoins et commencez à maximiser vos ventes dès aujourd'hui.
            </p>
            <div className="flex justify-center gap-4">
              <Button size="lg">
                Voir mes statistiques
              </Button>
              <Button size="lg" variant="outline">
                Contacter le service commercial
              </Button>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}