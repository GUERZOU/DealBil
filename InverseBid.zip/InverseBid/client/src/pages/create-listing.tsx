import { useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import ListingForm from "@/components/listings/listing-form";

export default function CreateListing() {
  const { user, isLoading } = useAuth();
  const [, navigate] = useLocation();

  // Redirect unauthenticated users to login page
  useEffect(() => {
    if (!isLoading && !user) {
      navigate("/auth");
    }
  }, [user, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="container mx-auto px-4 py-12 flex items-center justify-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
        <Footer />
      </div>
    );
  }

  // Handle case where user is not authenticated (should redirect)
  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="container mx-auto px-4 py-8 flex-grow">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold mb-6">Créer une nouvelle annonce</h1>
          <p className="text-gray-600 mb-6">
            Remplissez le formulaire ci-dessous pour mettre en vente votre article. Les acheteurs pourront 
            vous faire des propositions de prix que vous pourrez accepter ou refuser.
          </p>
          
          <ListingForm />
        </div>
      </main>
      <Footer />
    </div>
  );
}
