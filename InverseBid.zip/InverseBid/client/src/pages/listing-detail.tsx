import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Heart, User, MessageSquare, AlertTriangle, Share2, Clock, Tag, CheckCircle, Calendar } from "lucide-react";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import BidForm from "@/components/bids/bid-form";
import BidList from "@/components/bids/bid-list";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function ListingDetail() {
  const { id } = useParams<{ id: string }>();
  const listingId = parseInt(id);
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("details");

  const { data: listing, isLoading, error } = useQuery({
    queryKey: [`/api/listings/${listingId}`],
    enabled: !!id && !isNaN(listingId),
  });

  const handleContact = () => {
    if (!user) {
      navigate("/auth");
      return;
    }

    if (listing?.seller) {
      navigate(`/messages/${listing.seller.id}`);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="container mx-auto px-4 py-12 flex justify-center items-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
        <Footer />
      </div>
    );
  }

  if (error || !listing) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="container mx-auto px-4 py-12">
          <Card>
            <CardContent className="pt-6 flex flex-col items-center">
              <AlertTriangle className="text-red-500 w-12 h-12 mb-4" />
              <h1 className="text-2xl font-bold mb-2">Oups ! Une erreur est survenue</h1>
              <p className="text-gray-500 mb-4">
                {error instanceof Error ? error.message : "Impossible de charger cette annonce."}
              </p>
              <Button onClick={() => navigate("/")}>Retour à l'accueil</Button>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  // Format date
  const formattedDate = format(new Date(listing.createdAt), "d MMMM yyyy", { locale: fr });
  
  // Check if user is the seller
  const isSeller = user && user.id === listing.seller?.id;
  
  // Check if listing is active
  const isActive = listing.isActive;

  // Get seller initials for avatar
  const getSellerInitials = () => {
    if (listing.seller?.fullName) {
      return listing.seller.fullName
        .split(" ")
        .map(part => part[0])
        .join("")
        .toUpperCase()
        .substring(0, 2);
    }
    return listing.seller?.username.substring(0, 2).toUpperCase() || "?";
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="container mx-auto px-4 py-6 flex-grow">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Left column - Image and actions */}
          <div className="lg:w-2/3">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
              <div className="relative">
                <img 
                  src={listing.imageUrl || "https://via.placeholder.com/800x500?text=No+Image"} 
                  alt={listing.title}
                  className="w-full h-[400px] object-cover"
                />
                <div className="absolute top-4 right-4 flex space-x-2">
                  <Button variant="outline" size="icon" className="rounded-full bg-white/80 hover:bg-white">
                    <Heart className="h-5 w-5 text-gray-700" />
                  </Button>
                  <Button variant="outline" size="icon" className="rounded-full bg-white/80 hover:bg-white">
                    <Share2 className="h-5 w-5 text-gray-700" />
                  </Button>
                </div>
                {!isActive && (
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <Badge className="bg-red-500 text-white text-lg py-2 px-4">Enchère terminée</Badge>
                  </div>
                )}
              </div>
              
              <div className="p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                  <h1 className="text-2xl font-bold mb-2 md:mb-0">{listing.title}</h1>
                  <div className="flex items-center">
                    <span className="text-gray-500 mr-2">Prix de départ:</span>
                    <span className="text-xl font-bold text-primary">{listing.startingPrice}€</span>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  <Badge variant="outline" className="bg-primary/10 text-primary">
                    <Tag className="h-3.5 w-3.5 mr-1" />
                    {listing.category}
                  </Badge>
                  <Badge variant="outline" className="bg-green-50 text-green-600">
                    <CheckCircle className="h-3.5 w-3.5 mr-1" />
                    {listing.condition}
                  </Badge>
                  <Badge variant="outline" className="bg-blue-50 text-blue-600">
                    <Calendar className="h-3.5 w-3.5 mr-1" />
                    {formattedDate}
                  </Badge>
                  {isActive ? (
                    <Badge variant="outline" className="bg-green-50 text-green-600">
                      <Clock className="h-3.5 w-3.5 mr-1" />
                      Accepte les offres
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="bg-red-50 text-red-600">
                      <Clock className="h-3.5 w-3.5 mr-1" />
                      Enchère terminée
                    </Badge>
                  )}
                </div>
                
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="mb-4">
                    <TabsTrigger value="details">Détails</TabsTrigger>
                    {isSeller && <TabsTrigger value="bids">Offres reçues</TabsTrigger>}
                    {!isSeller && user && <TabsTrigger value="bid">Faire une offre</TabsTrigger>}
                  </TabsList>
                  
                  <TabsContent value="details" className="space-y-4">
                    <div>
                      <h2 className="text-lg font-semibold mb-2">Description</h2>
                      <p className="text-gray-700 whitespace-pre-line">{listing.description}</p>
                    </div>
                  </TabsContent>
                  
                  {isSeller && (
                    <TabsContent value="bids">
                      <BidList listingId={listingId} isSeller={true} />
                    </TabsContent>
                  )}
                  
                  {!isSeller && user && (
                    <TabsContent value="bid">
                      {isActive ? (
                        <BidForm listingId={listingId} startingPrice={listing.startingPrice} />
                      ) : (
                        <div className="py-4 text-center">
                          <AlertTriangle className="h-10 w-10 text-yellow-500 mx-auto mb-2" />
                          <p className="text-gray-600">Cette enchère est terminée et n'accepte plus d'offres.</p>
                        </div>
                      )}
                      <div className="mt-4">
                        <BidList listingId={listingId} isSeller={false} />
                      </div>
                    </TabsContent>
                  )}
                </Tabs>
              </div>
            </div>
          </div>
          
          {/* Right column - Seller info and actions */}
          <div className="lg:w-1/3">
            {/* Seller info card */}
            <Card className="mb-6">
              <CardContent className="pt-6">
                <h2 className="text-lg font-semibold mb-4">Informations sur le vendeur</h2>
                <div className="flex items-center mb-4">
                  <Avatar className="h-12 w-12 mr-4">
                    <AvatarImage src={listing.seller?.avatarUrl || ""} alt={listing.seller?.username} />
                    <AvatarFallback>{getSellerInitials()}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{listing.seller?.fullName || listing.seller?.username}</p>
                    <p className="text-sm text-gray-500">
                      {listing.seller?.userType === "individual" && "Particulier"}
                      {listing.seller?.userType === "business" && "Professionnel"}
                      {listing.seller?.userType === "wholesaler" && "Grossiste"}
                    </p>
                  </div>
                </div>
                
                <Separator className="mb-4" />
                
                {!isSeller && (
                  <div className="space-y-3">
                    {user ? (
                      <>
                        {isActive && (
                          <Button 
                            className="w-full"
                            onClick={() => setActiveTab("bid")}
                          >
                            Faire une offre
                          </Button>
                        )}
                        <Button 
                          variant="outline" 
                          className="w-full"
                          onClick={handleContact}
                        >
                          <MessageSquare className="mr-2 h-4 w-4" />
                          Contacter le vendeur
                        </Button>
                      </>
                    ) : (
                      <Button 
                        className="w-full"
                        onClick={() => navigate("/auth")}
                      >
                        <User className="mr-2 h-4 w-4" />
                        Connectez-vous pour interagir
                      </Button>
                    )}
                  </div>
                )}
                
                {isSeller && (
                  <div className="space-y-3">
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => navigate(`/my-listings`)}
                    >
                      Gérer mes annonces
                    </Button>
                    {isActive && (
                      <Button 
                        variant="secondary" 
                        className="w-full"
                        onClick={() => setActiveTab("bids")}
                      >
                        Voir les offres reçues
                      </Button>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
            
            {/* Safety tips */}
            <Card>
              <CardContent className="pt-6">
                <h2 className="text-lg font-semibold mb-4">Conseils de sécurité</h2>
                <ul className="space-y-3 text-sm">
                  <li className="flex">
                    <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2 flex-shrink-0" />
                    <span>Communiquez toujours via notre plateforme</span>
                  </li>
                  <li className="flex">
                    <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2 flex-shrink-0" />
                    <span>Ne payez jamais en dehors de notre système sécurisé</span>
                  </li>
                  <li className="flex">
                    <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2 flex-shrink-0" />
                    <span>Signalez tout comportement suspect à notre équipe</span>
                  </li>
                </ul>
                <Button variant="link" className="mt-2 p-0">En savoir plus sur la sécurité</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
