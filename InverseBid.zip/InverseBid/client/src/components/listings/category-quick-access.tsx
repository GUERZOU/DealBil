import { Link } from "wouter";
import { 
  Smartphone, 
  Laptop, 
  Shirt, 
  Sofa, 
  Car, 
  MoreHorizontal,
  Home
} from "lucide-react";

const categories = [
  { 
    id: "telephony", 
    name: "Téléphonie", 
    icon: <Smartphone className="text-primary text-xl" />,
    href: "/?category=telephony"
  },
  { 
    id: "computers", 
    name: "Informatique", 
    icon: <Laptop className="text-primary text-xl" />,
    href: "/?category=computers"
  },
  { 
    id: "clothing", 
    name: "Vêtements", 
    icon: <Shirt className="text-primary text-xl" />,
    href: "/?category=clothing"
  },
  { 
    id: "furniture", 
    name: "Meubles", 
    icon: <Sofa className="text-primary text-xl" />,
    href: "/?category=furniture"
  },
  { 
    id: "vehicles", 
    name: "Véhicules", 
    icon: <Car className="text-primary text-xl" />,
    href: "/?category=vehicles"
  },
  { 
    id: "realestate", 
    name: "Immobilier", 
    icon: <Home className="text-primary text-xl" />,
    href: "/?category=realestate"
  },
  { 
    id: "more", 
    name: "Voir plus", 
    icon: <MoreHorizontal className="text-primary text-xl" />,
    href: "/categories"
  }
];

export default function CategoryQuickAccess() {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-8">
      {categories.map((category) => (
        <Link 
          key={category.id}
          href={category.href}
          className="flex flex-col items-center bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition"
        >
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-2">
            {category.icon}
          </div>
          <span className="text-sm font-medium text-center">{category.name}</span>
        </Link>
      ))}
    </div>
  );
}
