import { Link } from "wouter";
import { Heart, CheckCircle, Clock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export type ListingCardProps = {
  id: number;
  title: string;
  startingPrice: number;
  imageUrl?: string | null;
  isPopular?: boolean;
  isNew?: boolean;
  seller: {
    id: number;
    username: string;
    fullName?: string;
    avatarUrl?: string | null;
  };
  createdAt: Date;
  status: "accepting_offers" | "in_negotiation" | "offer_accepted";
}

export default function ListingCard({
  id,
  title,
  startingPrice,
  imageUrl,
  isPopular,
  isNew,
  seller,
  createdAt,
  status
}: ListingCardProps) {
  
  // Calculate relative time for the listing
  const getRelativeTime = (date: Date) => {
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) return "À l'instant";
    if (diffInSeconds < 3600) return `Il y a ${Math.floor(diffInSeconds / 60)} minutes`;
    if (diffInSeconds < 86400) return `Il y a ${Math.floor(diffInSeconds / 3600)} heures`;
    if (diffInSeconds < 2592000) return `Il y a ${Math.floor(diffInSeconds / 86400)} jours`;
    
    return date.toLocaleDateString();
  };

  // Generate seller avatar fallback
  const getSellerInitials = () => {
    if (seller.fullName) {
      return seller.fullName
        .split(" ")
        .map(part => part[0])
        .join("")
        .toUpperCase()
        .substring(0, 2);
    }
    return seller.username.substring(0, 2).toUpperCase();
  };

  return (
    <Card className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition duration-300">
      <div className="relative">
        <img 
          src={imageUrl || "https://via.placeholder.com/400x200?text=No+Image"} 
          alt={title}
          className="w-full h-48 object-cover"
        />
        {isPopular && (
          <div className="absolute top-2 left-2">
            <Badge className="bg-orange-500 hover:bg-orange-600">Populaire</Badge>
          </div>
        )}
        {isNew && (
          <div className="absolute top-2 left-2">
            <Badge className="bg-primary hover:bg-primary/90">Nouveau</Badge>
          </div>
        )}
        <Button 
          variant="outline" 
          size="icon" 
          className="absolute top-2 right-2 bg-white/70 hover:bg-white text-gray-700 rounded-full"
        >
          <Heart className="h-4 w-4" />
        </Button>
      </div>
      
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-medium line-clamp-2">{title}</h3>
        </div>
        
        <div className="flex items-center mb-3">
          <span className="text-sm text-gray-500">Prix de départ:</span>
          <span className="ml-1 font-semibold">{startingPrice}€</span>
        </div>
        
        <div className="flex justify-between items-center mb-3">
          <div className="flex items-center">
            <Avatar className="h-6 w-6">
              <AvatarImage src={seller.avatarUrl || ""} alt={seller.username} />
              <AvatarFallback className="text-xs">{getSellerInitials()}</AvatarFallback>
            </Avatar>
            <span className="ml-1.5 text-xs text-gray-500">{seller.username}</span>
          </div>
          <span className="text-xs text-gray-500">{getRelativeTime(createdAt)}</span>
        </div>
        
        <div className="border-t border-gray-100 pt-3 flex justify-between">
          {status === "accepting_offers" && (
            <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">
              <CheckCircle className="mr-1 h-3 w-3" />
              Accepte les offres
            </Badge>
          )}
          
          {status === "in_negotiation" && (
            <Badge variant="outline" className="bg-blue-50 text-blue-600 border-blue-200">
              <Clock className="mr-1 h-3 w-3" />
              En négociation
            </Badge>
          )}
          
          {status === "offer_accepted" && (
            <Badge variant="outline" className="bg-red-50 text-red-600 border-red-200">
              <CheckCircle className="mr-1 h-3 w-3" />
              Offre acceptée
            </Badge>
          )}
          
          <Link href={`/listings/${id}`} className="text-primary text-sm font-medium hover:underline">
            Voir détails
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
