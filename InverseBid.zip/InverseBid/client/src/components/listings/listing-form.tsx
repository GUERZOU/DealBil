import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { insertListingSchema, InsertListing } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage,
  FormDescription
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

// Extend the schema with validation rules
const listingFormSchema = insertListingSchema.extend({
  title: z.string().min(5, "Le titre doit contenir au moins 5 caractères").max(100, "Le titre ne doit pas dépasser 100 caractères"),
  description: z.string().min(20, "La description doit contenir au moins 20 caractères"),
  startingPrice: z.preprocess(
    (val) => (val === "" ? undefined : Number(val)),
    z.number().positive("Le prix doit être supérieur à 0")
  ),
  imageUrl: z.string().optional().nullable(),
});

const categories = [
  { id: "electronics", label: "Électronique" },
  { id: "fashion", label: "Mode" },
  { id: "home", label: "Maison" },
  { id: "hobbies", label: "Loisirs" },
  { id: "auto", label: "Auto" },
  { id: "realestate", label: "Immobilier" },
  { id: "professional", label: "Professionnel" },
];

const conditions = [
  { id: "new", label: "Neuf" },
  { id: "like_new", label: "Très bon état" },
  { id: "good", label: "Bon état" },
  { id: "fair", label: "État moyen" },
];

export default function ListingForm() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [submitting, setSubmitting] = useState(false);

  const form = useForm<z.infer<typeof listingFormSchema>>({
    resolver: zodResolver(listingFormSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "electronics",
      condition: "new",
      startingPrice: 0,
      imageUrl: "",
    },
  });

  const createListingMutation = useMutation({
    mutationFn: async (data: InsertListing) => {
      const res = await apiRequest("POST", "/api/listings", data);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/listings"] });
      toast({
        title: "Annonce créée avec succès",
        description: "Votre annonce est maintenant visible par les acheteurs potentiels.",
      });
      navigate(`/listings/${data.id}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur lors de la création de l'annonce",
        description: error.message,
        variant: "destructive",
      });
    },
    onSettled: () => {
      setSubmitting(false);
    }
  });

  const onSubmit = (data: z.infer<typeof listingFormSchema>) => {
    setSubmitting(true);
    createListingMutation.mutate(data);
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Créer une nouvelle annonce</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Titre de l'annonce</FormLabel>
                  <FormControl>
                    <Input placeholder="Ex: iPhone 13 Pro 128Go" {...field} />
                  </FormControl>
                  <FormDescription>
                    Un titre clair et précis attire plus d'acheteurs.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Décrivez votre article en détail, ses caractéristiques, son état, etc." 
                      className="min-h-[120px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Catégorie</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionner une catégorie" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {categories.map(category => (
                          <SelectItem key={category.id} value={category.id}>
                            {category.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="condition"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>État</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionner l'état" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {conditions.map(condition => (
                          <SelectItem key={condition.id} value={condition.id}>
                            {condition.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="startingPrice"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Prix de départ (€)</FormLabel>
                  <FormControl>
                    <Input type="number" min="0" step="0.01" {...field} />
                  </FormControl>
                  <FormDescription>
                    Le prix minimum que vous souhaitez obtenir.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="imageUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>URL de l'image</FormLabel>
                  <FormControl>
                    <Input placeholder="https://example.com/your-image.jpg" {...field} />
                  </FormControl>
                  <FormDescription>
                    Fournissez un lien vers une image de votre article.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end space-x-2">
              <Button variant="outline" type="button" onClick={() => navigate("/")}>
                Annuler
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? "Création en cours..." : "Créer l'annonce"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
