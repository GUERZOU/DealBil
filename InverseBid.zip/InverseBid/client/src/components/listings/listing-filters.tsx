import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel
} from "@/components/ui/form";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger
} from "@/components/ui/accordion";
import { Card, CardContent, CardTitle } from "@/components/ui/card";

const filterSchema = z.object({
  sellerTypes: z.array(z.string()).optional(),
  minPrice: z.string().optional(),
  maxPrice: z.string().optional(),
  conditions: z.array(z.string()).optional(),
});

type FilterValues = z.infer<typeof filterSchema>;

type ListingFiltersProps = {
  onApplyFilters: (filters: {
    sellerTypes?: string[];
    minPrice?: number;
    maxPrice?: number;
    conditions?: string[];
  }) => void;
};

export default function ListingFilters({ onApplyFilters }: ListingFiltersProps) {
  const [expanded, setExpanded] = useState<string[]>(["seller-type", "price-range", "condition"]);
  
  const form = useForm<FilterValues>({
    resolver: zodResolver(filterSchema),
    defaultValues: {
      sellerTypes: [],
      minPrice: "",
      maxPrice: "",
      conditions: [],
    }
  });

  const handleSubmit = (values: FilterValues) => {
    // Convert string prices to numbers if they exist
    const minPrice = values.minPrice && values.minPrice !== "" ? parseFloat(values.minPrice) : undefined;
    const maxPrice = values.maxPrice && values.maxPrice !== "" ? parseFloat(values.maxPrice) : undefined;
    
    onApplyFilters({
      sellerTypes: values.sellerTypes?.length ? values.sellerTypes : undefined,
      minPrice,
      maxPrice,
      conditions: values.conditions?.length ? values.conditions : undefined,
    });
  };

  return (
    <Card className="mb-6">
      <CardContent className="pt-6">
        <CardTitle className="font-semibold text-lg mb-4">Filtres</CardTitle>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <Accordion 
              type="multiple" 
              value={expanded} 
              onValueChange={setExpanded}
              className="space-y-2"
            >
              <AccordionItem value="seller-type" className="border-b pb-2">
                <AccordionTrigger className="py-2 font-medium">Type de vendeur</AccordionTrigger>
                <AccordionContent className="space-y-2">
                  <FormField
                    control={form.control}
                    name="sellerTypes"
                    render={() => (
                      <div className="space-y-2">
                        {[
                          { id: "individual", label: "Particulier" },
                          { id: "business", label: "Professionnel" },
                          { id: "wholesaler", label: "Grossiste" }
                        ].map((sellerType) => (
                          <FormField
                            key={sellerType.id}
                            control={form.control}
                            name="sellerTypes"
                            render={({ field }) => (
                              <FormItem className="flex items-center space-x-2">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(sellerType.id)}
                                    onCheckedChange={(checked) => {
                                      const current = field.value || [];
                                      const updated = checked
                                        ? [...current, sellerType.id]
                                        : current.filter(value => value !== sellerType.id);
                                      field.onChange(updated);
                                    }}
                                  />
                                </FormControl>
                                <FormLabel className="text-sm font-normal cursor-pointer">
                                  {sellerType.label}
                                </FormLabel>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                    )}
                  />
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="price-range" className="border-b pb-2">
                <AccordionTrigger className="py-2 font-medium">Fourchette de prix</AccordionTrigger>
                <AccordionContent>
                  <div className="flex items-center space-x-2">
                    <FormField
                      control={form.control}
                      name="minPrice"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Input 
                              type="number" 
                              placeholder="Min" 
                              className="w-full rounded text-sm" 
                              {...field}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <span>-</span>
                    <FormField
                      control={form.control}
                      name="maxPrice"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Input 
                              type="number" 
                              placeholder="Max" 
                              className="w-full rounded text-sm" 
                              {...field}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="condition" className="border-b pb-2">
                <AccordionTrigger className="py-2 font-medium">État</AccordionTrigger>
                <AccordionContent className="space-y-2">
                  <FormField
                    control={form.control}
                    name="conditions"
                    render={() => (
                      <div className="space-y-2">
                        {[
                          { id: "new", label: "Neuf" },
                          { id: "like_new", label: "Très bon état" },
                          { id: "good", label: "Bon état" },
                          { id: "fair", label: "État moyen" }
                        ].map((condition) => (
                          <FormField
                            key={condition.id}
                            control={form.control}
                            name="conditions"
                            render={({ field }) => (
                              <FormItem className="flex items-center space-x-2">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(condition.id)}
                                    onCheckedChange={(checked) => {
                                      const current = field.value || [];
                                      const updated = checked
                                        ? [...current, condition.id]
                                        : current.filter(value => value !== condition.id);
                                      field.onChange(updated);
                                    }}
                                  />
                                </FormControl>
                                <FormLabel className="text-sm font-normal cursor-pointer">
                                  {condition.label}
                                </FormLabel>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                    )}
                  />
                </AccordionContent>
              </AccordionItem>
            </Accordion>
            
            <div className="mt-6">
              <Button type="submit" className="w-full">
                Appliquer les filtres
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
