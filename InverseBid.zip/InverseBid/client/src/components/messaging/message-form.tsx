import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertMessageSchema } from "@shared/schema";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send } from "lucide-react";

// Extend message schema with validation
const messageFormSchema = insertMessageSchema.extend({
  content: z.string().min(1, "Le message ne peut pas être vide")
});

type MessageFormProps = {
  receiverId: number;
};

export default function MessageForm({ receiverId }: MessageFormProps) {
  const { toast } = useToast();
  const [isSending, setIsSending] = useState(false);

  const form = useForm<z.infer<typeof messageFormSchema>>({
    resolver: zodResolver(messageFormSchema),
    defaultValues: {
      content: "",
      receiverId
    }
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (data: z.infer<typeof messageFormSchema>) => {
      const res = await apiRequest("POST", "/api/messages", data);
      return await res.json();
    },
    onSuccess: () => {
      // Reset the form
      form.reset({ content: "", receiverId });
      
      // Invalidate queries to refresh conversation
      queryClient.invalidateQueries({ queryKey: [`/api/conversations/${receiverId}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Échec de l'envoi",
        description: error.message,
        variant: "destructive"
      });
    },
    onSettled: () => {
      setIsSending(false);
    }
  });

  const onSubmit = (data: z.infer<typeof messageFormSchema>) => {
    setIsSending(true);
    sendMessageMutation.mutate(data);
  };

  return (
    <div className="border-t p-4">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="flex items-center space-x-2">
          <FormField
            control={form.control}
            name="content"
            render={({ field }) => (
              <FormItem className="flex-1">
                <FormControl>
                  <Input 
                    placeholder="Écrivez votre message..." 
                    {...field} 
                    disabled={isSending}
                  />
                </FormControl>
              </FormItem>
            )}
          />
          <Button type="submit" size="icon" disabled={isSending}>
            {isSending ? (
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            ) : (
              <Send className="h-4 w-4" />
            )}
          </Button>
        </form>
      </Form>
    </div>
  );
}
