import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Search } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";

type Conversation = {
  user: {
    id: number;
    username: string;
    fullName?: string;
    avatarUrl?: string | null;
  };
  lastMessage: {
    id: number;
    content: string;
    createdAt: string;
    senderId: number;
    isRead: boolean;
  };
  unreadCount: number;
};

type ConversationListProps = {
  selectedUserId?: number;
};

export default function ConversationList({ selectedUserId }: ConversationListProps) {
  const [, navigate] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");

  const { data: conversations, isLoading, error } = useQuery<Conversation[]>({
    queryKey: ["/api/messages"],
    refetchInterval: 10000, // Refetch every 10 seconds
  });

  const handleConversationClick = (userId: number) => {
    navigate(`/messages/${userId}`);
  };

  // Filter conversations based on search term
  const filteredConversations = conversations?.filter(conv => 
    conv.user?.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (conv.user?.fullName && conv.user.fullName.toLowerCase().includes(searchTerm.toLowerCase())) ||
    conv.lastMessage.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Format relative time
  const formatMessageDate = (date: string) => {
    return formatDistanceToNow(new Date(date), { addSuffix: true, locale: fr });
  };

  // Get user initials for avatar
  const getUserInitials = (name?: string, username?: string) => {
    if (name) {
      return name
        .split(" ")
        .map(part => part[0])
        .join("")
        .toUpperCase()
        .substring(0, 2);
    }
    return username ? username.substring(0, 2).toUpperCase() : "?";
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 text-center text-red-500">
        Une erreur est survenue lors du chargement des conversations.
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b">
        <div className="relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Rechercher une conversation..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
      
      <div className="flex-1 overflow-auto">
        {filteredConversations?.length === 0 ? (
          <div className="p-4 text-center text-gray-500">
            {searchTerm 
              ? "Aucune conversation ne correspond à votre recherche." 
              : "Vous n'avez pas de conversations."}
          </div>
        ) : (
          <div>
            {filteredConversations?.map((conversation) => (
              <Button
                key={conversation.user.id}
                variant="ghost"
                className={`w-full justify-start p-3 ${
                  selectedUserId === conversation.user.id ? "bg-primary/10" : ""
                }`}
                onClick={() => handleConversationClick(conversation.user.id)}
              >
                <div className="flex items-start w-full">
                  <div className="relative">
                    <Avatar className="h-10 w-10 mr-3">
                      <AvatarImage src={conversation.user.avatarUrl || ""} alt={conversation.user.username} />
                      <AvatarFallback>
                        {getUserInitials(conversation.user.fullName, conversation.user.username)}
                      </AvatarFallback>
                    </Avatar>
                    {conversation.unreadCount > 0 && (
                      <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center">
                        {conversation.unreadCount}
                      </Badge>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start">
                      <h3 className="font-medium truncate">
                        {conversation.user.fullName || conversation.user.username}
                      </h3>
                      <span className="text-xs text-gray-500 whitespace-nowrap ml-2">
                        {formatMessageDate(conversation.lastMessage.createdAt)}
                      </span>
                    </div>
                    <p className={`text-sm truncate ${conversation.unreadCount > 0 ? "font-medium" : "text-gray-500"}`}>
                      {conversation.lastMessage.content}
                    </p>
                  </div>
                </div>
              </Button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
