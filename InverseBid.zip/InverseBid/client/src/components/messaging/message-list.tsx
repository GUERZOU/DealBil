import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Message } from "@shared/schema";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Loader2 } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";

type ConversationData = {
  messages: Message[];
  user: {
    id: number;
    username: string;
    fullName?: string;
    avatarUrl?: string | null;
  } | null;
};

type MessageListProps = {
  receiverId: number;
};

export default function MessageList({ receiverId }: MessageListProps) {
  const { user } = useAuth();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [initialLoad, setInitialLoad] = useState(true);

  const { data, isLoading, error } = useQuery<ConversationData>({
    queryKey: [`/api/conversations/${receiverId}`],
    refetchInterval: 10000, // Poll every 10 seconds for new messages
  });

  // Scroll to bottom on initial load or when new messages arrive
  useEffect(() => {
    if (data?.messages && messagesEndRef.current) {
      if (initialLoad) {
        messagesEndRef.current.scrollIntoView();
        setInitialLoad(false);
      } else {
        messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
      }
    }
  }, [data?.messages, initialLoad]);

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center text-red-500 p-4">
        Erreur lors du chargement des messages: {error.message}
      </div>
    );
  }

  if (!data || !data.messages || data.messages.length === 0) {
    return (
      <div className="text-center text-gray-500 p-8">
        Aucun message dans cette conversation. Commencez à discuter !
      </div>
    );
  }

  const getInitials = (name?: string) => {
    if (!name) return "?";
    return name
      .split(" ")
      .map(part => part[0])
      .join("")
      .toUpperCase()
      .substring(0, 2);
  };

  const formatMessageDate = (date: Date) => {
    return formatDistanceToNow(date, { addSuffix: true, locale: fr });
  };

  return (
    <ScrollArea className="h-[480px] pr-4">
      <div className="space-y-4 p-4">
        {data.messages.map((message) => {
          const isCurrentUser = message.senderId === user?.id;
          const sender = isCurrentUser ? user : data.user;
          
          return (
            <div 
              key={message.id}
              className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex ${isCurrentUser ? 'flex-row-reverse' : 'flex-row'} items-start gap-2 max-w-[80%]`}>
                {!isCurrentUser && (
                  <Avatar className="h-8 w-8 mt-1">
                    <AvatarImage src={sender?.avatarUrl || ""} alt={sender?.username || "User"} />
                    <AvatarFallback>{getInitials(sender?.fullName)}</AvatarFallback>
                  </Avatar>
                )}
                
                <div>
                  <div 
                    className={`px-4 py-2 rounded-lg ${
                      isCurrentUser 
                        ? 'bg-primary text-white rounded-tr-none' 
                        : 'bg-gray-100 text-gray-800 rounded-tl-none'
                    }`}
                  >
                    {message.content}
                  </div>
                  <div className={`text-xs text-gray-500 mt-1 ${isCurrentUser ? 'text-right' : 'text-left'}`}>
                    {formatMessageDate(new Date(message.createdAt))}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>
    </ScrollArea>
  );
}
