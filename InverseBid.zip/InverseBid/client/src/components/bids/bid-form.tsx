import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

// Form schema with validation
const bidFormSchema = z.object({
  amount: z.preprocess(
    (val) => (val === "" ? undefined : Number(val)),
    z.number()
      .positive("Le montant doit être supérieur à 0")
      .refine(val => !isNaN(val), "Montant invalide")
  ),
});

type BidFormProps = {
  listingId: number;
  startingPrice: number;
};

export default function BidForm({ listingId, startingPrice }: BidFormProps) {
  const { toast } = useToast();
  const [submitting, setSubmitting] = useState(false);

  const form = useForm<z.infer<typeof bidFormSchema>>({
    resolver: zodResolver(bidFormSchema),
    defaultValues: {
      amount: startingPrice,
    },
  });

  const placeBidMutation = useMutation({
    mutationFn: async (data: { amount: number }) => {
      const res = await apiRequest("POST", "/api/bids", {
        listingId,
        amount: data.amount,
      });
      return await res.json();
    },
    onSuccess: () => {
      // Reset form and show success toast
      form.reset({ amount: startingPrice });
      toast({
        title: "Offre envoyée avec succès !",
        description: "Le vendeur a été notifié de votre proposition.",
      });
      // Invalidate related queries to refresh the data
      queryClient.invalidateQueries({ queryKey: [`/api/listings/${listingId}`] });
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur lors de l'envoi de l'offre",
        description: error.message,
        variant: "destructive",
      });
    },
    onSettled: () => {
      setSubmitting(false);
    }
  });

  const onSubmit = (data: z.infer<typeof bidFormSchema>) => {
    setSubmitting(true);
    placeBidMutation.mutate(data);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Proposer votre prix</CardTitle>
        <CardDescription>
          Faites une offre privée au vendeur en fonction de ce que vous êtes prêt à payer.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Montant proposé (€)</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      step="0.01" 
                      {...field} 
                      onChange={(e) => field.onChange(e.target.valueAsNumber || '')}
                    />
                  </FormControl>
                  <FormDescription>
                    Prix de départ: {startingPrice}€
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button 
              type="submit" 
              className="w-full" 
              disabled={submitting}
            >
              {submitting ? "Envoi en cours..." : "Envoyer mon offre"}
            </Button>
          </form>
        </Form>
        <div className="mt-4 text-sm text-gray-500">
          <p>Votre offre est privée et ne sera visible que par vous et le vendeur.</p>
          <p>Le vendeur pourra accepter, refuser ou ignorer votre offre.</p>
        </div>
      </CardContent>
    </Card>
  );
}
