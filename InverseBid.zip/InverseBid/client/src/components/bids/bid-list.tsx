import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Bid } from "@shared/schema";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { MessageSquare, CheckCircle, XCircle, Clock } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

type BidWithBidder = Bid & { 
  bidder?: { 
    id: number;
    username: string;
    fullName?: string;
    avatarUrl?: string | null;
  } 
};

type BidListProps = {
  listingId: number;
  isSeller: boolean;
};

export default function BidList({ listingId, isSeller }: BidListProps) {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [selectedBid, setSelectedBid] = useState<BidWithBidder | null>(null);
  const [actionType, setActionType] = useState<'accept' | 'reject' | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Fetch listing details which includes bids
  const { data: listingData, isLoading, error } = useQuery({
    queryKey: [`/api/listings/${listingId}`],
    enabled: !!listingId,
  });

  // Extract bids from listing data
  const bids = listingData?.bids || [];

  // Update bid status mutation
  const updateBidStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: 'accepted' | 'rejected' | 'pending' }) => {
      const res = await apiRequest("PUT", `/api/bids/${id}/status`, { status });
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: actionType === 'accept' ? "Offre acceptée !" : "Offre refusée",
        description: actionType === 'accept' 
          ? "L'acheteur a été notifié. Vous pouvez maintenant finaliser la transaction." 
          : "L'acheteur a été notifié du refus.",
      });
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/listings/${listingId}`] });
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur lors de la mise à jour",
        description: error.message,
        variant: "destructive",
      });
    },
    onSettled: () => {
      setSelectedBid(null);
      setActionType(null);
      setIsDialogOpen(false);
    }
  });

  const handleAcceptBid = (bid: BidWithBidder) => {
    setSelectedBid(bid);
    setActionType('accept');
    setIsDialogOpen(true);
  };

  const handleRejectBid = (bid: BidWithBidder) => {
    setSelectedBid(bid);
    setActionType('reject');
    setIsDialogOpen(true);
  };

  const confirmAction = () => {
    if (!selectedBid || !actionType) return;
    
    updateBidStatusMutation.mutate({
      id: selectedBid.id,
      status: actionType === 'accept' ? 'accepted' : 'rejected',
    });
  };

  const handleContact = (bidderId: number) => {
    navigate(`/messages/${bidderId}`);
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center p-8">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 text-center text-red-500">
        Erreur lors du chargement des offres
      </div>
    );
  }

  if (bids.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        {isSeller 
          ? "Vous n'avez encore reçu aucune offre pour cette annonce." 
          : "Vous n'avez pas encore fait d'offre pour cette annonce."}
      </div>
    );
  }

  // Format date
  const formatBidDate = (date: string | Date) => {
    return format(new Date(date), "d MMMM yyyy à HH:mm", { locale: fr });
  };

  // Get bidder initials for avatar
  const getBidderInitials = (bid: BidWithBidder) => {
    if (!bid.bidder) return "?";
    
    if (bid.bidder.fullName) {
      return bid.bidder.fullName
        .split(" ")
        .map(part => part[0])
        .join("")
        .toUpperCase()
        .substring(0, 2);
    }
    return bid.bidder.username.substring(0, 2).toUpperCase();
  };

  return (
    <>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              {isSeller && <TableHead>Acheteur</TableHead>}
              <TableHead>Montant</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Statut</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {bids.map((bid: BidWithBidder) => (
              <TableRow key={bid.id}>
                {isSeller && (
                  <TableCell>
                    <div className="flex items-center">
                      <Avatar className="h-8 w-8 mr-2">
                        <AvatarImage src={bid.bidder?.avatarUrl || ""} alt={bid.bidder?.username} />
                        <AvatarFallback>{getBidderInitials(bid)}</AvatarFallback>
                      </Avatar>
                      <span>{bid.bidder?.username}</span>
                    </div>
                  </TableCell>
                )}
                <TableCell className="font-medium">{bid.amount}€</TableCell>
                <TableCell>{formatBidDate(bid.createdAt)}</TableCell>
                <TableCell>
                  {bid.status === 'pending' && (
                    <Badge variant="outline" className="bg-blue-50 text-blue-600 border-blue-200">
                      <Clock className="mr-1 h-3 w-3" />
                      En attente
                    </Badge>
                  )}
                  {bid.status === 'accepted' && (
                    <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">
                      <CheckCircle className="mr-1 h-3 w-3" />
                      Acceptée
                    </Badge>
                  )}
                  {bid.status === 'rejected' && (
                    <Badge variant="outline" className="bg-red-50 text-red-600 border-red-200">
                      <XCircle className="mr-1 h-3 w-3" />
                      Refusée
                    </Badge>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  {isSeller && bid.status === 'pending' && (
                    <div className="flex justify-end gap-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="text-green-600 border-green-200 hover:bg-green-50"
                        onClick={() => handleAcceptBid(bid)}
                      >
                        <CheckCircle className="mr-1 h-3 w-3" />
                        Accepter
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="text-red-600 border-red-200 hover:bg-red-50"
                        onClick={() => handleRejectBid(bid)}
                      >
                        <XCircle className="mr-1 h-3 w-3" />
                        Refuser
                      </Button>
                    </div>
                  )}
                  {isSeller && bid.status !== 'pending' && (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleContact(bid.bidderId)}
                    >
                      <MessageSquare className="mr-1 h-3 w-3" />
                      Contacter
                    </Button>
                  )}
                  {!isSeller && (
                    <Badge variant="outline" className={
                      bid.status === 'pending' 
                        ? "bg-blue-50 text-blue-600 border-blue-200" 
                        : bid.status === 'accepted' 
                        ? "bg-green-50 text-green-600 border-green-200" 
                        : "bg-red-50 text-red-600 border-red-200"
                    }>
                      {bid.status === 'pending' && "En attente de réponse"}
                      {bid.status === 'accepted' && "Offre acceptée !"}
                      {bid.status === 'rejected' && "Offre refusée"}
                    </Badge>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <AlertDialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {actionType === 'accept' ? "Accepter cette offre ?" : "Refuser cette offre ?"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {actionType === 'accept' 
                ? "En acceptant cette offre, vous refuserez automatiquement toutes les autres offres et marquerez l'article comme vendu."
                : "Vous pouvez refuser cette offre si elle ne vous convient pas. L'acheteur en sera notifié."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmAction}
              className={actionType === 'accept' ? "bg-green-600" : "bg-red-600"}
            >
              {actionType === 'accept' ? "Oui, accepter" : "Oui, refuser"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
