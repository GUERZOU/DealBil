import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  Bell, 
  Mail, 
  ChevronDown,
  Menu,
  X,
  Search
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

type HeaderProps = {
  onSearch?: (query: string) => void;
};

const categories = [
  { id: "electronics", name: "Électronique" },
  { id: "fashion", name: "Mode" },
  { id: "home", name: "Maison" },
  { id: "hobbies", name: "Loisirs" },
  { id: "auto", name: "Auto" },
  { id: "realestate", name: "Immobilier" },
  { id: "professional", name: "Professionnels" },
];

export default function Header({ onSearch }: HeaderProps) {
  const { user, logoutMutation } = useAuth();
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearch && searchQuery.trim()) {
      onSearch(searchQuery);
    }
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  // Get user's initials for avatar fallback
  const getUserInitials = () => {
    if (!user?.fullName) return "U";
    return user.fullName
      .split(" ")
      .map(part => part[0])
      .join("")
      .toUpperCase()
      .substring(0, 2);
  };

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-3">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center justify-between w-full md:w-auto mb-4 md:mb-0">
            <Link href="/" className="flex items-center">
              <img src="/logo.svg" alt="DealBil" className="h-10 w-10 mr-2" />
              <span className="text-3xl font-bold text-primary font-sans">
                Deal<span className="text-orange-500">Bil</span>
              </span>
            </Link>
            
            <button 
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
          
          <div className="w-full md:w-1/2 mb-4 md:mb-0">
            <form onSubmit={handleSearch} className="relative">
              <Input
                type="text"
                placeholder="Rechercher un produit, une marque..."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-primary"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Button 
                type="submit"
                className="absolute right-0 top-0 h-full px-4 text-white rounded-r-lg hover:bg-opacity-90"
              >
                <Search className="h-4 w-4" />
              </Button>
            </form>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button asChild variant="default" className="mr-2 bg-orange-500 hover:bg-orange-600">
              <Link href="/create-listing">Déposer une annonce</Link>
            </Button>
            
            {user ? (
              <>
                <Link href="/messages" className="hidden md:flex items-center text-gray-800 hover:text-primary">
                  <Mail className="h-5 w-5" />
                  <Badge variant="secondary" className="ml-1 bg-primary text-white">2</Badge>
                </Link>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="flex items-center space-x-1 text-gray-800 hover:text-primary">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={user.avatarUrl || ""} alt={user.username} />
                        <AvatarFallback>{getUserInitials()}</AvatarFallback>
                      </Avatar>
                      <span className="hidden md:inline">{user.fullName}</span>
                      <ChevronDown className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48 py-1">
                    <DropdownMenuItem asChild>
                      <Link href="/profile">Mon profil</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/my-listings">Mes annonces</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/messages">Mes messages</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/monetization">Monétisation</Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout} className="text-red-500">
                      Déconnexion
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <Button asChild variant="outline">
                <Link href="/auth">Se connecter</Link>
              </Button>
            )}
          </div>
        </div>
        
        <nav className={`mt-3 ${mobileMenuOpen ? 'block' : 'hidden md:block'}`}>
          <ul className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-6 overflow-x-auto pb-2 text-sm md:text-base">
            <li>
              <Link 
                href="/" 
                className={`whitespace-nowrap px-3 py-2 rounded-lg ${location === '/' ? 'bg-gray-100' : 'hover:bg-gray-100'}`}
              >
                Accueil
              </Link>
            </li>
            {categories.map((category) => (
              <li key={category.id}>
                <Link 
                  href={`/?category=${category.id}`} 
                  className="whitespace-nowrap px-3 py-2 rounded-lg hover:bg-gray-100"
                >
                  {category.name}
                </Link>
              </li>
            ))}
            {user && (
              <li className="md:hidden">
                <Link 
                  href="/create-listing" 
                  className="whitespace-nowrap px-3 py-2 rounded-lg bg-orange-500 text-white hover:bg-orange-600"
                >
                  Déposer une annonce
                </Link>
              </li>
            )}
          </ul>
        </nav>
      </div>
    </header>
  );
}
