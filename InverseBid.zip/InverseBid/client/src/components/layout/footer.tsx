import { Link } from "wouter";
import { Facebook, Twitter, Instagram, Linkedin, Send } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

export default function Footer() {
  return (
    <footer className="bg-white pt-10 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="font-sans font-semibold text-lg mb-4">À propos</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="#" className="text-gray-600 hover:text-primary">Qui sommes-nous</Link></li>
              <li><Link href="#" className="text-gray-600 hover:text-primary">Comment ça marche</Link></li>
              <li><Link href="#" className="text-gray-600 hover:text-primary">Nos engagements</Link></li>
              <li><Link href="#" className="text-gray-600 hover:text-primary">Carrières</Link></li>
              <li><Link href="#" className="text-gray-600 hover:text-primary">Presse</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-sans font-semibold text-lg mb-4">Aide et contact</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="#" className="text-gray-600 hover:text-primary">Centre d'aide</Link></li>
              <li><Link href="#" className="text-gray-600 hover:text-primary">Contact</Link></li>
              <li><Link href="#" className="text-gray-600 hover:text-primary">Signaler un problème</Link></li>
              <li><Link href="#" className="text-gray-600 hover:text-primary">Guide de sécurité</Link></li>
              <li><Link href="#" className="text-gray-600 hover:text-primary">Conditions d'utilisation</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-sans font-semibold text-lg mb-4">Services professionnels</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="#" className="text-gray-600 hover:text-primary">Espace vendeurs pro</Link></li>
              <li><Link href="#" className="text-gray-600 hover:text-primary">Solutions pour grossistes</Link></li>
              <li><Link href="#" className="text-gray-600 hover:text-primary">Publicité</Link></li>
              <li><Link href="#" className="text-gray-600 hover:text-primary">Affiliation</Link></li>
              <li><Link href="#" className="text-gray-600 hover:text-primary">API développeurs</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-sans font-semibold text-lg mb-4">Restez connectés</h3>
            <div className="flex space-x-4 mb-4">
              <Button variant="outline" size="icon" className="rounded-full">
                <Facebook className="h-5 w-5 text-primary" />
              </Button>
              <Button variant="outline" size="icon" className="rounded-full">
                <Twitter className="h-5 w-5 text-primary" />
              </Button>
              <Button variant="outline" size="icon" className="rounded-full">
                <Instagram className="h-5 w-5 text-primary" />
              </Button>
              <Button variant="outline" size="icon" className="rounded-full">
                <Linkedin className="h-5 w-5 text-primary" />
              </Button>
            </div>
            <h3 className="font-sans font-semibold text-lg mb-3">Newsletter</h3>
            <form className="flex">
              <Input 
                type="email" 
                placeholder="Votre email" 
                className="rounded-r-none"
              />
              <Button type="submit" className="rounded-l-none">
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </div>
        
        <Separator className="my-6" />
        
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0 flex items-center">
            <img src="/logo.svg" alt="DealBil" className="h-8 w-8 mr-2" />
            <p className="text-sm text-gray-500">&copy; 2023 DealBil. Tous droits réservés.</p>
          </div>
          <div className="flex space-x-4">
            <Link href="#" className="text-sm text-gray-500 hover:text-primary">Confidentialité</Link>
            <Link href="#" className="text-sm text-gray-500 hover:text-primary">Conditions d'utilisation</Link>
            <Link href="#" className="text-sm text-gray-500 hover:text-primary">Cookies</Link>
            <Link href="#" className="text-sm text-gray-500 hover:text-primary">Accessibilité</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
