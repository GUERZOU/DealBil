import { 
  users, User, InsertUser, 
  listings, Listing, InsertListing,
  bids, Bid, InsertBid,
  messages, Message, InsertMessage
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User | undefined>;

  // Listing operations
  createListing(listing: InsertListing & { sellerId: number }): Promise<Listing>;
  getListing(id: number): Promise<Listing | undefined>;
  getListings(options?: { 
    category?: string;
    condition?: string;
    sellerType?: string;
    minPrice?: number;
    maxPrice?: number;
    isActive?: boolean;
    limit?: number;
    offset?: number;
    promoted?: boolean;
  }): Promise<Listing[]>;
  getUserListings(userId: number): Promise<Listing[]>;
  updateListing(id: number, data: Partial<Listing>): Promise<Listing | undefined>;
  deleteListing(id: number): Promise<boolean>;

  // Bid operations
  createBid(bid: InsertBid & { bidderId: number }): Promise<Bid>;
  getBid(id: number): Promise<Bid | undefined>;
  getListingBids(listingId: number): Promise<Bid[]>;
  getUserBids(userId: number): Promise<Bid[]>;
  updateBidStatus(id: number, status: 'accepted' | 'rejected' | 'pending'): Promise<Bid | undefined>;

  // Message operations
  createMessage(message: InsertMessage & { senderId: number }): Promise<Message>;
  getUserMessages(userId: number): Promise<Message[]>;
  getConversation(user1Id: number, user2Id: number): Promise<Message[]>;
  markMessageAsRead(id: number): Promise<Message | undefined>;

  // Subscription operations
  getSubscriptionPlans(): Promise<SubscriptionPlan[]>;
  getSubscriptionPlan(id: number): Promise<SubscriptionPlan | undefined>;
  createSubscriptionPlan(plan: InsertSubscriptionPlan): Promise<SubscriptionPlan>;
  getUserSubscription(userId: number): Promise<UserSubscription | undefined>;
  createUserSubscription(subscription: InsertUserSubscription): Promise<UserSubscription>;
  updateUserSubscription(id: number, data: Partial<UserSubscription>): Promise<UserSubscription | undefined>;
  
  // Promotion operations
  getPromotionTypes(): Promise<PromotionType[]>;
  getPromotionType(id: number): Promise<PromotionType | undefined>;
  createPromotionType(promotionType: InsertPromotionType): Promise<PromotionType>;
  getListingPromotions(listingId: number): Promise<ListingPromotion[]>;
  createListingPromotion(promotion: InsertListingPromotion): Promise<ListingPromotion>;
  getActiveListingPromotions(): Promise<ListingPromotion[]>;
  updateListingPromotionStatus(id: number, status: string): Promise<ListingPromotion | undefined>;
  
  // Transaction operations
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getTransaction(id: number): Promise<Transaction | undefined>;
  getUserTransactions(userId: number): Promise<Transaction[]>;
  updateTransactionStatus(id: number, status: string): Promise<Transaction | undefined>;
  
  // Advertisement operations
  getAdSpaces(): Promise<AdSpace[]>;
  getAdSpace(id: number): Promise<AdSpace | undefined>;
  createAdSpace(adSpace: InsertAdSpace): Promise<AdSpace>;
  updateAdSpace(id: number, data: Partial<AdSpace>): Promise<AdSpace | undefined>;
  getAdCampaigns(userId?: number): Promise<AdCampaign[]>;
  getAdCampaign(id: number): Promise<AdCampaign | undefined>;
  createAdCampaign(campaign: InsertAdCampaign): Promise<AdCampaign>;
  updateAdCampaign(id: number, data: Partial<AdCampaign>): Promise<AdCampaign | undefined>;
  incrementAdCampaignImpressions(id: number): Promise<AdCampaign | undefined>;
  incrementAdCampaignClicks(id: number): Promise<AdCampaign | undefined>;

  // Session store
  sessionStore: session.SessionStore;
}

// Memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private listings: Map<number, Listing>;
  private bids: Map<number, Bid>;
  private messages: Map<number, Message>;
  sessionStore: session.SessionStore;
  private userIdCounter: number;
  private listingIdCounter: number;
  private bidIdCounter: number;
  private messageIdCounter: number;

  constructor() {
    this.users = new Map();
    this.listings = new Map();
    this.bids = new Map();
    this.messages = new Map();
    this.userIdCounter = 1;
    this.listingIdCounter = 1;
    this.bidIdCounter = 1;
    this.messageIdCounter = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 24 hours
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase()
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: now,
      avatarUrl: null
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, data: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Listing methods
  async createListing(listing: InsertListing & { sellerId: number }): Promise<Listing> {
    const id = this.listingIdCounter++;
    const now = new Date();
    const newListing: Listing = {
      ...listing,
      id,
      isActive: true,
      createdAt: now,
      imageUrl: listing.imageUrl || null
    };
    this.listings.set(id, newListing);
    return newListing;
  }

  async getListing(id: number): Promise<Listing | undefined> {
    return this.listings.get(id);
  }

  async getListings(options: {
    category?: string;
    condition?: string;
    sellerType?: string;
    minPrice?: number;
    maxPrice?: number;
    isActive?: boolean;
    limit?: number;
    offset?: number;
  } = {}): Promise<Listing[]> {
    let listings = Array.from(this.listings.values());
    
    if (options.isActive !== undefined) {
      listings = listings.filter(listing => listing.isActive === options.isActive);
    }
    
    if (options.category) {
      listings = listings.filter(listing => listing.category === options.category);
    }
    
    if (options.condition) {
      listings = listings.filter(listing => listing.condition === options.condition);
    }
    
    if (options.minPrice !== undefined) {
      listings = listings.filter(listing => listing.startingPrice >= options.minPrice!);
    }
    
    if (options.maxPrice !== undefined) {
      listings = listings.filter(listing => listing.startingPrice <= options.maxPrice!);
    }
    
    if (options.sellerType) {
      listings = listings.filter(async listing => {
        const seller = await this.getUser(listing.sellerId);
        return seller?.userType === options.sellerType;
      });
    }
    
    // Sort by most recent first
    listings.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    const offset = options.offset || 0;
    const limit = options.limit || listings.length;
    
    return listings.slice(offset, offset + limit);
  }

  async getUserListings(userId: number): Promise<Listing[]> {
    const listings = Array.from(this.listings.values())
      .filter(listing => listing.sellerId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    return listings;
  }

  async updateListing(id: number, data: Partial<Listing>): Promise<Listing | undefined> {
    const listing = this.listings.get(id);
    if (!listing) return undefined;
    
    const updatedListing = { ...listing, ...data };
    this.listings.set(id, updatedListing);
    return updatedListing;
  }

  async deleteListing(id: number): Promise<boolean> {
    return this.listings.delete(id);
  }

  // Bid methods
  async createBid(bid: InsertBid & { bidderId: number }): Promise<Bid> {
    const id = this.bidIdCounter++;
    const now = new Date();
    const newBid: Bid = {
      ...bid,
      id,
      status: 'pending',
      createdAt: now
    };
    this.bids.set(id, newBid);
    return newBid;
  }

  async getBid(id: number): Promise<Bid | undefined> {
    return this.bids.get(id);
  }

  async getListingBids(listingId: number): Promise<Bid[]> {
    const bids = Array.from(this.bids.values())
      .filter(bid => bid.listingId === listingId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    return bids;
  }

  async getUserBids(userId: number): Promise<Bid[]> {
    const bids = Array.from(this.bids.values())
      .filter(bid => bid.bidderId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    return bids;
  }

  async updateBidStatus(id: number, status: 'accepted' | 'rejected' | 'pending'): Promise<Bid | undefined> {
    const bid = this.bids.get(id);
    if (!bid) return undefined;
    
    const updatedBid = { ...bid, status };
    this.bids.set(id, updatedBid);
    
    // If a bid is accepted, reject all other bids for this listing
    if (status === 'accepted') {
      const otherBids = Array.from(this.bids.values())
        .filter(b => b.listingId === bid.listingId && b.id !== id);
      
      for (const otherBid of otherBids) {
        const rejectedBid = { ...otherBid, status: 'rejected' as const };
        this.bids.set(otherBid.id, rejectedBid);
      }
      
      // Mark the listing as inactive
      const listing = this.listings.get(bid.listingId);
      if (listing) {
        const updatedListing = { ...listing, isActive: false };
        this.listings.set(listing.id, updatedListing);
      }
    }
    
    return updatedBid;
  }

  // Message methods
  async createMessage(message: InsertMessage & { senderId: number }): Promise<Message> {
    const id = this.messageIdCounter++;
    const now = new Date();
    const newMessage: Message = {
      ...message,
      id,
      isRead: false,
      createdAt: now
    };
    this.messages.set(id, newMessage);
    return newMessage;
  }

  async getUserMessages(userId: number): Promise<Message[]> {
    const messages = Array.from(this.messages.values())
      .filter(message => message.senderId === userId || message.receiverId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    return messages;
  }

  async getConversation(user1Id: number, user2Id: number): Promise<Message[]> {
    const messages = Array.from(this.messages.values())
      .filter(message => 
        (message.senderId === user1Id && message.receiverId === user2Id) ||
        (message.senderId === user2Id && message.receiverId === user1Id)
      )
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
    
    return messages;
  }

  async markMessageAsRead(id: number): Promise<Message | undefined> {
    const message = this.messages.get(id);
    if (!message) return undefined;
    
    const updatedMessage = { ...message, isRead: true };
    this.messages.set(id, updatedMessage);
    return updatedMessage;
  }
}

export const storage = new MemStorage();
