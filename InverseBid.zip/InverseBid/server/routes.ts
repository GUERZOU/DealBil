import type { Express, Request, Response } from "express";
import express from "express";
import { createServer, type Server } from "http";
import path from "path";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { 
  insertListingSchema, 
  insertBidSchema, 
  insertMessageSchema 
} from "@shared/schema";

// Authentication middleware
const isAuthenticated = (req: Request, res: Response, next: Function) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).send("Unauthorized");
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup static files serving from public directory
  app.use(express.static(path.join(process.cwd(), 'public')));
  
  // Setup authentication routes
  setupAuth(app);

  // Listings API
  app.get("/api/listings", async (req, res) => {
    try {
      const { 
        category, 
        condition, 
        sellerType, 
        minPrice, 
        maxPrice, 
        limit, 
        offset 
      } = req.query;
      
      const options = {
        category: category as string | undefined,
        condition: condition as string | undefined,
        sellerType: sellerType as string | undefined,
        minPrice: minPrice ? parseFloat(minPrice as string) : undefined,
        maxPrice: maxPrice ? parseFloat(maxPrice as string) : undefined,
        isActive: true, // Only show active listings by default
        limit: limit ? parseInt(limit as string) : 20,
        offset: offset ? parseInt(offset as string) : 0
      };
      
      const listings = await storage.getListings(options);
      
      // Fetch seller information for each listing
      const listingsWithSellers = await Promise.all(listings.map(async (listing) => {
        const seller = await storage.getUser(listing.sellerId);
        return {
          ...listing,
          seller: seller ? {
            id: seller.id,
            username: seller.username,
            fullName: seller.fullName,
            userType: seller.userType,
            avatarUrl: seller.avatarUrl
          } : null
        };
      }));
      
      res.json(listingsWithSellers);
    } catch (error) {
      console.error("Error fetching listings:", error);
      res.status(500).send("Error fetching listings");
    }
  });

  app.get("/api/listings/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const listing = await storage.getListing(id);
      
      if (!listing) {
        return res.status(404).send("Listing not found");
      }
      
      // Get seller info
      const seller = await storage.getUser(listing.sellerId);
      
      // Get bids if user is authenticated and is either the seller or has placed a bid
      let bids = [];
      if (req.isAuthenticated()) {
        const user = req.user as Express.User;
        
        if (user.id === listing.sellerId) {
          // Seller can see all bids
          bids = await storage.getListingBids(id);
          
          // Add bidder info to each bid
          bids = await Promise.all(bids.map(async (bid) => {
            const bidder = await storage.getUser(bid.bidderId);
            return {
              ...bid,
              bidder: bidder ? {
                id: bidder.id,
                username: bidder.username,
                fullName: bidder.fullName,
                avatarUrl: bidder.avatarUrl
              } : null
            };
          }));
        } else {
          // Bidder can only see their own bids
          const userBids = await storage.getListingBids(id);
          bids = userBids.filter(bid => bid.bidderId === user.id);
        }
      }
      
      res.json({
        ...listing,
        seller: seller ? {
          id: seller.id,
          username: seller.username,
          fullName: seller.fullName,
          userType: seller.userType,
          avatarUrl: seller.avatarUrl
        } : null,
        bids
      });
    } catch (error) {
      console.error("Error fetching listing:", error);
      res.status(500).send("Error fetching listing");
    }
  });

  app.post("/api/listings", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertListingSchema.parse(req.body);
      const user = req.user as Express.User;
      
      const listing = await storage.createListing({
        ...validatedData,
        sellerId: user.id
      });
      
      res.status(201).json(listing);
    } catch (error) {
      console.error("Error creating listing:", error);
      res.status(400).send(`Error creating listing: ${error}`);
    }
  });

  app.put("/api/listings/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const listing = await storage.getListing(id);
      const user = req.user as Express.User;
      
      if (!listing) {
        return res.status(404).send("Listing not found");
      }
      
      if (listing.sellerId !== user.id) {
        return res.status(403).send("Not authorized to update this listing");
      }
      
      const updatedListing = await storage.updateListing(id, req.body);
      res.json(updatedListing);
    } catch (error) {
      console.error("Error updating listing:", error);
      res.status(500).send("Error updating listing");
    }
  });

  app.delete("/api/listings/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const listing = await storage.getListing(id);
      const user = req.user as Express.User;
      
      if (!listing) {
        return res.status(404).send("Listing not found");
      }
      
      if (listing.sellerId !== user.id) {
        return res.status(403).send("Not authorized to delete this listing");
      }
      
      await storage.deleteListing(id);
      res.sendStatus(204);
    } catch (error) {
      console.error("Error deleting listing:", error);
      res.status(500).send("Error deleting listing");
    }
  });

  // Bids API
  app.post("/api/bids", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertBidSchema.parse(req.body);
      const user = req.user as Express.User;
      
      // Check if listing exists and is active
      const listing = await storage.getListing(validatedData.listingId);
      if (!listing) {
        return res.status(404).send("Listing not found");
      }
      
      if (!listing.isActive) {
        return res.status(400).send("This listing is no longer accepting bids");
      }
      
      // Check if user is not the seller
      if (listing.sellerId === user.id) {
        return res.status(400).send("You cannot bid on your own listing");
      }
      
      const bid = await storage.createBid({
        ...validatedData,
        bidderId: user.id
      });
      
      res.status(201).json(bid);
    } catch (error) {
      console.error("Error creating bid:", error);
      res.status(400).send(`Error creating bid: ${error}`);
    }
  });

  app.get("/api/users/:userId/bids", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const user = req.user as Express.User;
      
      if (userId !== user.id) {
        return res.status(403).send("Not authorized to view these bids");
      }
      
      const bids = await storage.getUserBids(userId);
      
      // Add listing info to each bid
      const bidsWithListings = await Promise.all(bids.map(async (bid) => {
        const listing = await storage.getListing(bid.listingId);
        return {
          ...bid,
          listing: listing || null
        };
      }));
      
      res.json(bidsWithListings);
    } catch (error) {
      console.error("Error fetching user bids:", error);
      res.status(500).send("Error fetching user bids");
    }
  });

  app.put("/api/bids/:id/status", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      const user = req.user as Express.User;
      
      if (!status || !['accepted', 'rejected', 'pending'].includes(status)) {
        return res.status(400).send("Invalid status");
      }
      
      // Get the bid
      const bid = await storage.getBid(id);
      if (!bid) {
        return res.status(404).send("Bid not found");
      }
      
      // Get the listing to check ownership
      const listing = await storage.getListing(bid.listingId);
      if (!listing) {
        return res.status(404).send("Listing not found");
      }
      
      if (listing.sellerId !== user.id) {
        return res.status(403).send("Not authorized to update this bid");
      }
      
      const updatedBid = await storage.updateBidStatus(id, status as 'accepted' | 'rejected' | 'pending');
      res.json(updatedBid);
    } catch (error) {
      console.error("Error updating bid status:", error);
      res.status(500).send("Error updating bid status");
    }
  });

  // Messages API
  app.post("/api/messages", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertMessageSchema.parse(req.body);
      const user = req.user as Express.User;
      
      // Check if receiver exists
      const receiver = await storage.getUser(validatedData.receiverId);
      if (!receiver) {
        return res.status(404).send("Receiver not found");
      }
      
      const message = await storage.createMessage({
        ...validatedData,
        senderId: user.id
      });
      
      res.status(201).json(message);
    } catch (error) {
      console.error("Error sending message:", error);
      res.status(400).send(`Error sending message: ${error}`);
    }
  });

  app.get("/api/messages", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as Express.User;
      const messages = await storage.getUserMessages(user.id);
      
      // Group messages by conversation
      const conversations = new Map<number, any>();
      
      for (const message of messages) {
        const otherUserId = message.senderId === user.id ? message.receiverId : message.senderId;
        
        if (!conversations.has(otherUserId)) {
          const otherUser = await storage.getUser(otherUserId);
          
          conversations.set(otherUserId, {
            user: otherUser ? {
              id: otherUser.id,
              username: otherUser.username,
              fullName: otherUser.fullName,
              avatarUrl: otherUser.avatarUrl
            } : null,
            lastMessage: message,
            unreadCount: message.senderId !== user.id && !message.isRead ? 1 : 0
          });
        } else {
          const conversation = conversations.get(otherUserId);
          
          // Update last message if newer
          if (message.createdAt > conversation.lastMessage.createdAt) {
            conversation.lastMessage = message;
          }
          
          // Count unread messages
          if (message.senderId !== user.id && !message.isRead) {
            conversation.unreadCount++;
          }
          
          conversations.set(otherUserId, conversation);
        }
      }
      
      res.json(Array.from(conversations.values()));
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).send("Error fetching messages");
    }
  });

  app.get("/api/conversations/:userId", isAuthenticated, async (req, res) => {
    try {
      const otherUserId = parseInt(req.params.userId);
      const user = req.user as Express.User;
      
      const messages = await storage.getConversation(user.id, otherUserId);
      
      // Mark received messages as read
      await Promise.all(
        messages
          .filter(msg => msg.receiverId === user.id && !msg.isRead)
          .map(msg => storage.markMessageAsRead(msg.id))
      );
      
      // Get user information
      const otherUser = await storage.getUser(otherUserId);
      
      res.json({
        messages,
        user: otherUser ? {
          id: otherUser.id,
          username: otherUser.username,
          fullName: otherUser.fullName,
          avatarUrl: otherUser.avatarUrl
        } : null
      });
    } catch (error) {
      console.error("Error fetching conversation:", error);
      res.status(500).send("Error fetching conversation");
    }
  });

  // User listings
  app.get("/api/users/:userId/listings", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const listings = await storage.getUserListings(userId);
      
      res.json(listings);
    } catch (error) {
      console.error("Error fetching user listings:", error);
      res.status(500).send("Error fetching user listings");
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
