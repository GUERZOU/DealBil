import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  userType: text("user_type").notNull(), // individual, business, wholesaler
  avatarUrl: text("avatar_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  avatarUrl: true,
});

// Listing schema
export const listings = pgTable("listings", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  condition: text("condition").notNull(), // new, like new, good, fair
  startingPrice: doublePrecision("starting_price").notNull(),
  imageUrl: text("image_url"),
  sellerId: integer("seller_id").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertListingSchema = createInsertSchema(listings).omit({
  id: true,
  sellerId: true,
  isActive: true,
  createdAt: true,
});

// Bid schema
export const bids = pgTable("bids", {
  id: serial("id").primaryKey(),
  listingId: integer("listing_id").notNull(),
  bidderId: integer("bidder_id").notNull(),
  amount: doublePrecision("amount").notNull(),
  status: text("status").default("pending").notNull(), // pending, accepted, rejected
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertBidSchema = createInsertSchema(bids).omit({
  id: true,
  bidderId: true,
  status: true,
  createdAt: true,
});

// Message schema
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").notNull(),
  receiverId: integer("receiver_id").notNull(),
  content: text("content").notNull(),
  isRead: boolean("is_read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  senderId: true,
  isRead: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Listing = typeof listings.$inferSelect;
export type InsertListing = z.infer<typeof insertListingSchema>;
export type Bid = typeof bids.$inferSelect;
export type InsertBid = z.infer<typeof insertBidSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

// Subscription plans
export const subscriptionPlans = pgTable("subscription_plans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  price: decimal("price").notNull(),
  billingCycle: text("billing_cycle").notNull(), // monthly, quarterly, yearly
  features: text("features").array().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSubscriptionPlanSchema = createInsertSchema(subscriptionPlans).omit({
  id: true,
  createdAt: true,
});

export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect;
export type InsertSubscriptionPlan = z.infer<typeof insertSubscriptionPlanSchema>;

// User subscriptions
export const userSubscriptions = pgTable("user_subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  planId: integer("plan_id").references(() => subscriptionPlans.id, { onDelete: "restrict" }).notNull(),
  startDate: timestamp("start_date").defaultNow().notNull(),
  endDate: timestamp("end_date").notNull(),
  autoRenew: boolean("auto_renew").default(true).notNull(),
  status: text("status").notNull(), // active, canceled, expired
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSubscriptionSchema = createInsertSchema(userSubscriptions).omit({
  id: true,
  createdAt: true,
});

export type UserSubscription = typeof userSubscriptions.$inferSelect;
export type InsertUserSubscription = z.infer<typeof insertUserSubscriptionSchema>;

// Listing promotions
export const promotionTypes = pgTable("promotion_types", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: decimal("price").notNull(),
  duration: integer("duration").notNull(), // in days
  features: text("features").array().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPromotionTypeSchema = createInsertSchema(promotionTypes).omit({
  id: true,
  createdAt: true,
});

export type PromotionType = typeof promotionTypes.$inferSelect;
export type InsertPromotionType = z.infer<typeof insertPromotionTypeSchema>;

// Applied promotions
export const listingPromotions = pgTable("listing_promotions", {
  id: serial("id").primaryKey(),
  listingId: integer("listing_id").references(() => listings.id, { onDelete: "cascade" }).notNull(),
  promotionTypeId: integer("promotion_type_id").references(() => promotionTypes.id, { onDelete: "restrict" }).notNull(),
  startDate: timestamp("start_date").defaultNow().notNull(),
  endDate: timestamp("end_date").notNull(),
  status: text("status").notNull(), // active, expired
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertListingPromotionSchema = createInsertSchema(listingPromotions).omit({
  id: true,
  createdAt: true,
});

export type ListingPromotion = typeof listingPromotions.$inferSelect;
export type InsertListingPromotion = z.infer<typeof insertListingPromotionSchema>;

// Transactions and commission tracking
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  listingId: integer("listing_id").references(() => listings.id, { onDelete: "restrict" }).notNull(),
  bidId: integer("bid_id").references(() => bids.id, { onDelete: "restrict" }).notNull(),
  sellerId: integer("seller_id").references(() => users.id, { onDelete: "restrict" }).notNull(),
  buyerId: integer("buyer_id").references(() => users.id, { onDelete: "restrict" }).notNull(),
  amount: decimal("amount").notNull(),
  commission: decimal("commission").notNull(),
  status: text("status").notNull(), // pending, completed, canceled
  paymentMethod: text("payment_method").notNull(),
  transactionDate: timestamp("transaction_date").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
});

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

// Advertising spaces
export const adSpaces = pgTable("ad_spaces", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  location: text("location").notNull(), // header, sidebar, listing_page, etc.
  size: text("size").notNull(), // small, medium, large
  price: decimal("price").notNull(), // per day
  isAvailable: boolean("is_available").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAdSpaceSchema = createInsertSchema(adSpaces).omit({
  id: true,
  createdAt: true,
});

export type AdSpace = typeof adSpaces.$inferSelect;
export type InsertAdSpace = z.infer<typeof insertAdSpaceSchema>;

// Ad campaigns
export const adCampaigns = pgTable("ad_campaigns", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  adSpaceId: integer("ad_space_id").references(() => adSpaces.id, { onDelete: "restrict" }).notNull(),
  title: text("title").notNull(),
  imageUrl: text("image_url").notNull(),
  targetUrl: text("target_url").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  status: text("status").notNull(), // pending, active, completed, canceled
  impressions: integer("impressions").default(0).notNull(),
  clicks: integer("clicks").default(0).notNull(),
  budget: decimal("budget").notNull(),
  spent: decimal("spent").default("0").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAdCampaignSchema = createInsertSchema(adCampaigns).omit({
  id: true,
  impressions: true,
  clicks: true,
  spent: true,
  createdAt: true,
});

export type AdCampaign = typeof adCampaigns.$inferSelect;
export type InsertAdCampaign = z.infer<typeof insertAdCampaignSchema>;
